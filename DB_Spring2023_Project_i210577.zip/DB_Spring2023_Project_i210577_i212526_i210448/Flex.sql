create database Flex;
use Flex;

create table Semester
(semester_id INT,
season VARCHAR(20),
year VARCHAR(4),
PRIMARY KEY (semester_id)
)

create table Course
(course_id INT,
course_name VARCHAR(20),
course_code VARCHAR(20),
credit_hours INT,
coordinator_id VARCHAR(20),
prereq_id INT,
PRIMARY KEY (course_id),
FOREIGN KEY (prereq_id) REFERENCES Course (course_id)
)

create table Section
(section_name CHAR,
PRIMARY KEY (section_name)
)

create table Users
(user_id VARCHAR(20),
password VARCHAR(8),
first_name VARCHAR(20),
last_name VARCHAR(20),
user_type CHAR,
PRIMARY KEY(user_id)
)

create table Semester_Section_Course
(semester_id INT,
course_id INT,
section_name CHAR,
PRIMARY KEY (semester_id,course_id, section_name),
FOREIGN KEY (semester_id) REFERENCES Semester(semester_id),
FOREIGN KEY (section_name) REFERENCES Section (section_name),
FOREIGN KEY (course_id) REFERENCES Course (course_id),
)


create table Student_Semester_Section_Course -- student takes course
(user_id VARCHAR(20),
semester_id INT,
course_id INT,
section_name CHAR,
grade VARCHAR(2) DEFAULT 'I',
PRIMARY KEY (user_id, semester_id, course_id, section_name),
FOREIGN KEY (semester_id, course_id, section_name) REFERENCES Semester_Section_Course (semester_id, course_id, section_name),
FOREIGN KEY (user_id) REFERENCES Users (user_id)
)


create table Faculty_Semester_Section_Course -- faculty teaches course
(user_id VARCHAR(20),
semester_id INT,
course_id INT,
section_name CHAR,
PRIMARY KEY (user_id, semester_id, course_id, section_name),
FOREIGN KEY (semester_id, course_id, section_name) REFERENCES  Semester_Section_Course (semester_id, course_id, section_name),
FOREIGN KEY (user_id) REFERENCES Users (user_id)
)

create table Evaluation
(eval_id INT,
obtained_marks NUMERIC DEFAULT 0,
total_marks NUMERIC,
type VARCHAR(20),
semester_id INT,
course_id INT,
section_name CHAR,
student_user_id VARCHAR(20),
PRIMARY KEY (eval_id),
FOREIGN KEY (semester_id, course_id, section_name) REFERENCES  Semester_Section_Course (semester_id, course_id, section_name),
FOREIGN KEY (student_user_id) REFERENCES Users (user_id)
)

create table Distribution_Course
(disid INT,
weightage NUMERIC DEFAULT 0,
type VARCHAR(20),
semester_id INT,
course_id INT,
section_name CHAR,
PRIMARY KEY (disid),
FOREIGN KEY (semester_id, course_id,section_name) REFERENCES  Semester_Section_Course (semester_id, course_id,section_name),
)

create table Lecture
(lecture_id INT,
lecture_date date,
duration NUMERIC,
room VARCHAR(10),
semester_id INT,
course_id INT,
section_name CHAR,
PRIMARY KEY (lecture_id),
FOREIGN KEY (semester_id, course_id, section_name) REFERENCES  Semester_Section_Course (semester_id, course_id, section_name)
)

create table Student_Takes_Lecture
(user_id VARCHAR(20),
lecture_id INT,
PRIMARY KEY (user_id, lecture_id),
FOREIGN KEY (lecture_id) REFERENCES Lecture (lecture_id),
FOREIGN KEY (user_id) REFERENCES Users (user_id)
)

create table Feedback
(feedback_id INT,
feedback_date date,
f1 INT,
f2 INT,
f3 INT,
f4 INT,
f5 INT,
f6 INT,
f7 INT,
f8 INT,
f9 INT,
f10 INT,
f11 INT,
f12 INT,
f13 INT,
f14 INT,
f15 INT,
f16 INT,
f17 INT,
f18 INT,
f19 INT,
f20 INT,
comments VARCHAR (250),
student_user_id VARCHAR(20),
semester_id INT,
course_id INT,
section_name CHAR,
PRIMARY KEY (feedback_id),
FOREIGN KEY (student_user_id) REFERENCES Users (user_id),
FOREIGN KEY (semester_id, course_id, section_name) REFERENCES  Semester_Section_Course (semester_id, course_id, section_name)
)

CREATE TABLE OfferedCourses  --course if offered in particular semester
(course_id int,
semester_id int,
PRIMARY KEY (course_id,semester_id),
FOREIGN KEY (course_id) REFERENCES Course (course_id),
FOREIGN KEY (semester_id) REFERENCES Semester (semester_id),
)

SELECT CONCAT(Semester.season, '-', Semester.year) AS semester, course_name AS course_names FROM OfferedCourses JOIN Course ON OfferedCourses.course_id = Course.course_id JOIN Semester ON Semester.semester_id = OfferedCourses.semester_id;
SELECT CONCAT(Semester.season, '-', Semester.year) from Semester;
SELECT course_name from OfferedCourses join Course on OfferedCourses.course_id = Course.course_id where semester_id = 1;
Select Count(distinct(course_id)) from Faculty_Semester_Section_Course where semester_id =1 and user_id='faisalcheems';


CREATE TABLE AppliedforCourse
(user_id varchar(20),
course_id int,
semester_id int,
registered char DEFAULT 'N',
PRIMARY KEY(user_id,course_id),
FOREIGN KEY(user_id) REFERENCES Users(user_id),
FOREIGN KEY(course_id) REFERENCES Course(course_id),
FOREIGN KEY(semester_id) REFERENCES Semester(semester_id),
)




ALTER TABLE Course 
ADD FOREIGN KEY (coordinator_id) REFERENCES Users (user_id);


Insert into Users Values ('21I-0577','2106600','Afaq','Arif','S');
Insert into Users Values ('21I-0448','2106601','Prince','Raza','S');
Insert into Users Values ('21I-2526','2106602','Sameer','Clutch','S');
Insert into Users Values ('faisalcheems','iamdumb','Faisal','Cheema','F');
Insert into Users Values ('amnairum','iamcool','Amna','Irum','F');
Insert into Users Values ('usmanrashid','iammid','Usman','Rashid','F');

Insert into Semester Values(1,'Spring','2022');
Insert into Semester Values(2,'Fall','2022');

Insert into Course Values(0,'lol','no',0,'faisalcheems',0);

Insert into Course Values(10,'PF','CS1002',3,'faisalcheems',0);
Insert into Course Values(20,'OOP','CS1004',3,'faisalcheems',10);
Insert into Course Values(30,'Data Structures','CS1006',3,'faisalcheems',20);

Insert into Section Values('H');
Insert into Section Values('F');

Insert into Semester_Section_Course Values (1,10,'H');
Insert into Semester_Section_Course Values (1,10,'F');
Insert into Semester_Section_Course Values (1,20,'H');
Insert into Semester_Section_Course Values (2,30,'H');
Insert into Semester_Section_Course Values (3,5,'H');

Insert into Faculty_Semester_Section_Course Values ('faisalcheems',1,10,'H');
Insert into Faculty_Semester_Section_Course Values ('faisalcheems',1,10,'F');
Insert into Faculty_Semester_Section_Course Values ('faisalcheems',1,20,'H');
Insert into Faculty_Semester_Section_Course Values ('faisalcheems',2,30,'H');

Insert into Distribution_Course Values (1,10,'Quiz',1,10,'H');
Insert into Distribution_Course Values (2,10,'Assignment',1,10,'H');
Insert into Distribution_Course Values (3,15,'Sessional-1',1,10,'H');
Insert into Distribution_Course Values (4,15,'Sessional-2',1,10,'H');
Insert into Distribution_Course Values (5,50,'Final',1,10,'H');

Insert into Distribution_Course Values (6,20,'Quiz',1,20,'H');
Insert into Distribution_Course Values (7,20,'Assignment',1,20,'H');
Insert into Distribution_Course Values (8,20,'Sessional-1',1,20,'H');
Insert into Distribution_Course Values (9,20,'Sessional-2',1,20,'H');
Insert into Distribution_Course Values (10,20,'Final',1,20,'H');


Insert into Student_Semester_Section_Course Values ('21I-0577',1,10,'H','I');
Insert into Student_Semester_Section_Course Values ('21I-0448',1,20,'H','I');
Insert into Student_Semester_Section_Course Values ('21I-2526',1,10,'H','I');

Insert into Evaluation Values (1,10,10,'Quiz',1,10,'H','21I-0577');
Insert into Evaluation Values (2,10,10,'Assignment',1,10,'H','21I-0577');
Insert into Evaluation Values (3,10,10,'Sessional-1',1,10,'H','21I-0577');
Insert into Evaluation Values (4,10,10,'Sessional-2',1,10,'H','21I-0577');
Insert into Evaluation Values (5,10,10,'Final',1,10,'H','21I-0577');
Insert into Evaluation Values (6,10,10,'Project',1,10,'H','21I-0577');

Insert into Evaluation Values (7,10,10,'Quiz',1,20,'H','21I-0448');
Insert into Evaluation Values (8,5,10,'Assignment',1,20,'H','21I-0448');
Insert into Evaluation Values (9,10,10,'Sessional-1',1,20,'H','21I-0448');
Insert into Evaluation Values (10,10,10,'Sessional-2',1,20,'H','21I-0448');
Insert into Evaluation Values (11,10,10,'Final',1,20,'H','21I-0448');
Insert into Evaluation Values (12,10,10,'Project',1,20,'H','21I-0448');

Insert into Evaluation Values (19,10,10,'Quiz',1,10,'H','21I-2526');
Insert into Evaluation Values (20,5,10,'Assignment',1,10,'H','21I-2526');
Insert into Evaluation Values (21,10,10,'Sessional-1',1,10,'H','21I-2526');
Insert into Evaluation Values (22,10,10,'Sessional-2',1,10,'H','21I-2526');
Insert into Evaluation Values (23,10,10,'Final',1,10,'H','21I-2526');
Insert into Evaluation Values (24,10,10,'Project',1,10,'H','21I-2526');

Insert into Feedback Values (0,'2022-7-1',1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,'good teach','21I-0577',1,10,'H');
Insert into Feedback Values (1,'2022-7-1',1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,'good teach','21I-2526',1,10,'H');

Insert into Users Values('amir.rehman','pls','Amir','Rehman','A');
Insert into Users Values('notset','justtobe','n','o','A');

Insert into OfferedCourses Values (10,1);
Insert into OfferedCourses Values (20,1);
Insert into OfferedCourses Values (30,2);

Insert into AppliedforCourse values ('21I-9999',10,1);
Insert into Student_Semester_Section_Course Values ('21I-9999',1,10,'H','B+');
Insert into AppliedforCourse values ('21I-9999',20,1,'N');

INSERT INTO Users VALUES ('21I-9998', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9997', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9996', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9995', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9994', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9993', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9992', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9991', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9990', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9989', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9988', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9987', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9986', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9985', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9984', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9983', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9982', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9981', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9980', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9979', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9978', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9977', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9976', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9975', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9974', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9973', 'bankai', 'Ichigo', 'Uzumaki', 'S');


INSERT INTO Users VALUES ('21I-9972', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9971', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9970', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9969', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9968', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9967', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9966', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9965', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9964', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9963', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9962', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9961', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9960', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9959', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9958', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9957', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9956', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9955', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9954', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9953', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9952', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9951', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9950', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9949', 'bankai', 'Ichigo', 'Uzumaki', 'S');
INSERT INTO Users VALUES ('21I-9948', 'bankai', 'Ichigo', 'Uzumaki', 'S');

INSERT INTO AppliedforCourse VALUES ('21I-9998', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9997', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9996', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9995', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9994', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9993', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9992', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9991', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9990', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9989', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9988', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9987', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9986', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9985', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9984', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9983', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9982', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9981', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9980', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9979', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9978', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9977', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9976', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9975', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9974', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9973', 20, 1, 'R');

INSERT INTO AppliedforCourse VALUES ('21I-9972', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9971', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9970', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9969', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9968', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9967', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9966', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9965', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9964', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9963', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9962', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9961', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9960', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9959', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9958', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9957', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9956', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9955', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9954', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9953', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9952', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9951', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9950', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9949', 20, 1, 'R');
INSERT INTO AppliedforCourse VALUES ('21I-9948', 20, 1, 'R');

Insert into Users values ('21I-9999','bankai','Ichigo','Uzumaki','S');







---Queries---
select course_code,course_name,section_name from Faculty_Semester_Section_Course join Course on Faculty_Semester_Section_Course.course_id = Course.course_id  where user_id = 'faisalcheems';
select course_name+'-'+season+'-'+year from Faculty_Semester_Section_Course join Course on Faculty_Semester_Section_Course.course_id = Course.course_id join Semester on Faculty_Semester_Section_Course.semester_id = Semester.semester_id  where user_id = 'faisalcheems'
select * from Course;
select count(*) from Semester;
select * from AppliedforCourse where course_id = 20 and semester_id=1 and registered ='R' ;
select * from Semester;
select * from Evaluation;
select * from Distribution_Course;
select * from Student_Semester_Section_Course;
select * from Faculty_Semester_Section_Course;
select *from Users;
select * from OfferedCourses;
select * from Semester_Section_Course;
select * from AppliedforCourse;



Select count(*) from Student_Semester_Section_Course where section_name='A';


select weightage,type from Distribution_Course where course_id = 10 and semester_id=1;
select course_id from Course where course_name = 'OOP'; 
select Course.course_id, Semester.semester_id from Course join Semester_Section_Course on Course.course_id =Semester_Section_Course.course_id join Semester on Semester_Section_Course.semester_id =Semester.semester_id where course_name = 'PF' and Semester.season='Spring' and Semester.year='2022';
UPDATE Distribution_Course SET weightage =  30  WHERE course_id = 10  AND semester_id = 1 AND type = 'Quiz';
select * from Student_Semester_Section_Course;
Select user_id from Student_Semester_Section_Course where semester_id = 1 and course_id = 10 and section_name = 'H';
Select * from Evaluation where semester_id =1 and course_id = 10 and section_name = 'H'  and student_user_id = '21I-0448';
UPDATE Student_Semester_Section_Course SET grade='I' where semester_id = 1 and course_id = 10 and section_name = 'H';
Select * from Lecture;
Select * from Student_Takes_Lecture;
Select Count(*) from Lecture;
Select * from Feedback;
Select student_user_id,comments,feedback_date,f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,1f4,f15,f16,f17,f18,f19,f20 from Feedback where semester_id=1 and course_id = 10

Select course_code,course_name,credit_hours,coordinator_id,STRING_AGG(section_name,','),STRING_AGG(user_id,',') from Course join Faculty_Semester_Section_Course on Course.course_id =Faculty_Semester_Section_Course.course_id where Course.course_id!=0 group by course_code,course_name,credit_hours,coordinator_id;
SELECT Course.course_id FROM OfferedCourses JOIN Course ON Course.course_id = OfferedCourses.course_id WHERE course_name = '' 
Select count(*) from Student_Semester_Section_Course where user_id = '21I-9999'; 

Select distinct section_name from Student_Semester_Section_Course;
select Users.user_id, CONCAT(first_name,' ',last_name) from Users join Student_Semester_Section_Course on Users.user_id = Student_Semester_Section_Course.user_id where section_name = 'A' order by USers.user_id;




--------------------------------------------------------------------------------------------------------------------------------------------

drop table AppliedforCourse;
drop table Feedback
drop table Student_Takes_Lecture
drop table Lecture
drop table Evaluation
drop table Distribution_Course
drop table Faculty_Semester_Section_Course
drop table Student_Semester_Section_Course
drop table Semester_Section_Course
drop table course
drop table users 
drop table semester
drop table section
