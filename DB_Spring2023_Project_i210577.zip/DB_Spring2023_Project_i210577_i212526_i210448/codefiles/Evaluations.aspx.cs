﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace FlexClutch
{
    public partial class Evaluations : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();

                if (!Page.IsPostBack)
                {
                    BindDropDownCourses();
                    BindDropDownStudents();

                    Courses.EnableViewState = true;
                    Students.EnableViewState = true;
                }

                string value = Courses.SelectedValue;
                int i = Courses.SelectedValue.IndexOf('-');
                int j = Courses.SelectedValue.IndexOf('-', i + 1);
                int k = Courses.SelectedValue.IndexOf('-', j + 1);

                string course = value.Substring(0, i);
                string season = value.Substring(i + 1, j - (i + 1));
                string year = value.Substring(j + 1, k - (j + 1));
                string section = value.Substring(k + 1, value.Length - (k + 1));

                int cid;
                int semid;

                string query = "select Course.course_id,Semester.semester_id from Course join Semester_Section_Course on Course.course_id =Semester_Section_Course.course_id join Semester on Semester_Section_Course.semester_id =Semester.semester_id where course_name = '" + course + "' and season= '" + season + "' and year='" + year + "'";
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    SqlDataReader dr = cm.ExecuteReader();
                    dr.Read();
                    cid = dr.GetInt32(0);
                    semid = dr.GetInt32(1);
                    dr.Close();

                    ifevalsexist(cid,semid,section,Students.SelectedValue);  
                }
            }
        }


         protected void Courses_SelectedIndexChanged(object sender, EventArgs e)
         {
            BindDropDownStudents();

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                string value = Courses.SelectedValue;
                int i = Courses.SelectedValue.IndexOf('-');
                int j = Courses.SelectedValue.IndexOf('-', i + 1);
                int k = Courses.SelectedValue.IndexOf('-', j + 1);

                string course = value.Substring(0, i);
                string season = value.Substring(i + 1, j - (i + 1));
                string year = value.Substring(j + 1, k - (j + 1));
                string section = value.Substring(k + 1, value.Length - (k + 1));

                int cid;
                int semid;

                string query = "select Course.course_id,Semester.semester_id from Course join Semester_Section_Course on Course.course_id =Semester_Section_Course.course_id join Semester on Semester_Section_Course.semester_id =Semester.semester_id where course_name = '" + course + "' and season= '" + season + "' and year='" + year + "'";
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    SqlDataReader dr = cm.ExecuteReader();
                    dr.Read();
                    cid = dr.GetInt32(0);
                    semid = dr.GetInt32(1);
                    dr.Close();
                    ifevalsexist(cid, semid, section, Students.SelectedValue);
                }
            }

    }

         protected void Students_SelectedIndexChanged(object sender, EventArgs e)
         {
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                string value = Courses.SelectedValue;
                int i = Courses.SelectedValue.IndexOf('-');
                int j = Courses.SelectedValue.IndexOf('-', i + 1);
                int k = Courses.SelectedValue.IndexOf('-', j + 1);

                string course = value.Substring(0, i);
                string season = value.Substring(i + 1, j - (i + 1));
                string year = value.Substring(j + 1, k - (j + 1));
                string section = value.Substring(k + 1, value.Length - (k + 1));

                int cid;
                int semid;

                string query = "select Course.course_id,Semester.semester_id from Course join Semester_Section_Course on Course.course_id =Semester_Section_Course.course_id join Semester on Semester_Section_Course.semester_id =Semester.semester_id where course_name = '" + course + "' and season= '" + season + "' and year='" + year + "'";
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    SqlDataReader dr = cm.ExecuteReader();
                    dr.Read();
                    cid = dr.GetInt32(0);
                    semid = dr.GetInt32(1);
                    dr.Close();
                    ifevalsexist(cid, semid, section, Students.SelectedValue);
                }
            }
         }

         protected void BindDropDownCourses()
         {
                SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True");
                conn.Open();

                SqlDataReader _reader = (SqlDataReader)Session["sr"];

                SqlCommand cm1;
                string query1 = "select course_name+'-'+season+'-'+year+'-'+section_name as CourseInfo from Faculty_Semester_Section_Course join Course on Faculty_Semester_Section_Course.course_id = Course.course_id join Semester on Faculty_Semester_Section_Course.semester_id = Semester.semester_id  where user_id = '" + _reader.GetString(0) + "'";
                cm1 = new SqlCommand(query1, conn);
                SqlDataReader dr1 = cm1.ExecuteReader();

                Courses.DataSource = dr1;
                Courses.DataTextField = "CourseInfo"; // Specify the display field name from your data source
                Courses.DataValueField = "CourseInfo"; // Specify the value field name from your data source
                Courses.DataBind();
                // Close the SqlDataReader
                dr1.Close();
         }

        protected void BindDropDownStudents()
        {
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();

                string value = Courses.SelectedValue;
                int i = value.IndexOf('-');
                int j = value.IndexOf('-', i + 1);
                int k = value.IndexOf('-', j + 1);

                string course = value.Substring(0, i);
                string season = value.Substring(i + 1, j - (i + 1));
                string year = value.Substring(j + 1, k - (j + 1));
                string section = value.Substring(k + 1, value.Length - (k + 1));

                int cid;
                int semid;

                string query = "SELECT Course.course_id, Semester.semester_id FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = @course AND season = @season AND year = @year";
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@course", course);
                    cm.Parameters.AddWithValue("@season", season);
                    cm.Parameters.AddWithValue("@year", year);

                    SqlDataReader dr = cm.ExecuteReader();
                    if (dr.Read())
                    {
                        cid = dr.GetInt32(0);
                        semid = dr.GetInt32(1);
                        dr.Close();

                        string studentQuery = "SELECT user_id FROM Student_Semester_Section_Course WHERE semester_id = @semid AND course_id = @cid AND section_name = @section";
                        using (SqlCommand cm1 = new SqlCommand(studentQuery, conn))
                        {
                            cm1.Parameters.AddWithValue("@semid", semid);
                            cm1.Parameters.AddWithValue("@cid", cid);
                            cm1.Parameters.AddWithValue("@section", section);

                            SqlDataReader dr1 = cm1.ExecuteReader();

                            List<string> students = new List<string>();
                            while (dr1.Read())
                            {
                                string studentId = dr1.GetString(0);
                                students.Add(studentId);
                            }

                            Students.DataSource = students;
                            Students.DataBind();

                            // Close the SqlDataReader
                            dr1.Close();
                        }
                    }
                }
            }
        }




        protected void ifevalsexist(int cid, int semid, string section, string student)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                //if evals already exist
                string ifquery = "Select * from Evaluation where semester_id =" + semid.ToString() + "and course_id = " + cid.ToString() + "and section_name = '" + section + "' and student_user_id = '" + student + "'";
                using (SqlCommand cmd = new SqlCommand(ifquery, conn))
                {
                    SqlDataReader ifexists = cmd.ExecuteReader();
                    if (ifexists.HasRows)
                    {
                        while (ifexists.Read())
                        {

                            if (String.Equals(ifexists.GetString(3), "Quiz"))
                            {
                                Qo.Text = ifexists.GetDecimal(1).ToString();
                                Qw.Text = ifexists.GetDecimal(2).ToString(); ;
                            }
                            if (String.Equals(ifexists.GetString(3), "Assignment"))
                            {
                                Ao.Text = ifexists.GetDecimal(1).ToString();
                                Aw.Text = ifexists.GetDecimal(2).ToString();
                            }
                            if (String.Equals(ifexists.GetString(3), "Sessional-1"))
                            {
                                Sess1o.Text = ifexists.GetDecimal(1).ToString();
                                S1w.Text = ifexists.GetDecimal(2).ToString();
                            }
                            if (String.Equals(ifexists.GetString(3), "Sessional-2"))
                            {
                                Sess2o.Text = ifexists.GetDecimal(1).ToString();
                                S2w.Text = ifexists.GetDecimal(2).ToString();
                            }
                            if (String.Equals(ifexists.GetString(3), "Final"))
                            {
                                Finalo.Text = ifexists.GetDecimal(1).ToString();
                                Fw.Text = ifexists.GetDecimal(2).ToString();
                            }
                            if (String.Equals(ifexists.GetString(3), "Project"))
                            {
                                Projecto.Text = ifexists.GetDecimal(1).ToString();
                                Pw.Text = ifexists.GetDecimal(1).ToString();
                            }
                        }

                        calctotal();
                    }
                    else
                    {
                        //insert values
                    }
                }
            }
        }

        protected void calctotal()
        {
            Decimal obtsum = 0;
            obtsum += Decimal.Parse(Qo.Text);
            obtsum += Decimal.Parse(Ao.Text);
            obtsum += Decimal.Parse(Sess1o.Text);
            obtsum += Decimal.Parse(Sess2o.Text);
            obtsum += Decimal.Parse(Finalo.Text);
            obtsum += Decimal.Parse(Projecto.Text);

            TOB.Text = obtsum.ToString();

            Decimal tsum = 0;
            tsum += Decimal.Parse(Qw.Text);
            tsum += Decimal.Parse(Aw.Text);
            tsum += Decimal.Parse(S1w.Text);
            tsum += Decimal.Parse(S2w.Text);
            tsum += Decimal.Parse(Fw.Text);
            tsum += Decimal.Parse(Pw.Text);

            TM.Text = tsum.ToString();

        }

        protected void QoButton_Click(object sender, EventArgs e)
        {

            string newValue1 = Request.Form[Qo.UniqueID];
            string oldval1 = Qo.Text;
            Qo.Text = newValue1;


            // Retrieve the course, season, and year values from DropDownList1
            string value = Courses.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            int k = value.IndexOf('-', j + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, k-(j+1));
            string query1 = "SELECT Course.course_id, Semester.semester_id,section_name FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);
                    string section = dr.GetString(2);
                    string user_id = Students.SelectedValue;
                    dr.Close();

                    string updateQuery = "UPDATE Evaluation SET obtained_marks = " + newValue1 +" WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Quiz'" + "and student_user_id = '"+user_id+"'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Decimal.Parse(newValue1)<=Decimal.Parse(Qw.Text))
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            MessageBox.Show("Please enter valid obtained marks");
                            Qo.Text = oldval1;
                            return;
                        }
                    }
                }
            }
        }

        protected void AoButton_Click(object sender, EventArgs e)
        {

            string newValue1 = Request.Form[Ao.UniqueID];
            string oldval1 = Ao.Text;
            Ao.Text = newValue1;


            // Retrieve the course, season, and year values from DropDownList1
            string value = Courses.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            int k = value.IndexOf('-', j + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, k - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id,section_name FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);
                    string section = dr.GetString(2);
                    string user_id = Students.SelectedValue;
                    dr.Close();

                    string updateQuery = "UPDATE Evaluation SET obtained_marks = " + newValue1 + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Assignment'" + "and student_user_id = '" + user_id + "'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Decimal.Parse(newValue1) <= Decimal.Parse(Aw.Text))
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            MessageBox.Show("Please enter valid obtained marks");
                            Ao.Text = oldval1;
                            return;
                        }
                    }
                }
            }

        }

        protected void Sess1Button_Click(object sender, EventArgs e)
        {

            string newValue = Request.Form[S1w.UniqueID];
            string oldval = S1w.Text;
            S1w.Text = newValue;

            string newValue1 = Request.Form[Sess1o.UniqueID];
            string oldval1 = Sess1o.Text;
            Sess1o.Text = newValue1;


            // Retrieve the course, season, and year values from DropDownList1
            string value = Courses.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            int k = value.IndexOf('-', j + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, k - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id,section_name FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);
                    string section = dr.GetString(2);
                    string user_id = Students.SelectedValue;
                    dr.Close();

                    string updateQuery = "UPDATE Evaluation SET obtained_marks = " + newValue1 + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Sessional-1'" + "and student_user_id = '" + user_id + "'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Decimal.Parse(newValue1) <= Decimal.Parse(S1w.Text))
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            MessageBox.Show("Please enter valid obtained marks");
                            Sess1o.Text = oldval;
                            return;
                        }
                    }
                }
            }

        }

        protected void Sess2Button_Click(object sender, EventArgs e)
        {

            string newValue = Request.Form[S2w.UniqueID];
            string oldval = S2w.Text;
            S2w.Text = newValue;

            string newValue1 = Request.Form[Sess2o.UniqueID];
            string oldval1 = Sess2o.Text;
            Sess2o.Text = newValue1;


            // Retrieve the course, season, and year values from DropDownList1
            string value = Courses.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            int k = value.IndexOf('-', j + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, k - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id,section_name FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);
                    string section = dr.GetString(2);
                    string user_id = Students.SelectedValue;
                    dr.Close();

                    string updateQuery = "UPDATE Evaluation SET obtained_marks = " + newValue1+ " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Sessional-2'" + "and student_user_id = '" + user_id + "'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Decimal.Parse(newValue1) <= Decimal.Parse(S2w.Text))
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            MessageBox.Show("Please enter valid obtained marks");
                            Sess2o.Text = oldval;
                            return;
                        }
                    }
                }
            }
        }

        protected void FinalButton_Click(object sender, EventArgs e)
        {

            string newValue1 = Request.Form[Finalo.UniqueID];
            string oldval1 = Finalo.Text;
            Finalo.Text = newValue1;


            // Retrieve the course, season, and year values from DropDownList1
            string value = Courses.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            int k = value.IndexOf('-', j + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, k - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id,section_name FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);
                    string section = dr.GetString(2);
                    string user_id = Students.SelectedValue;
                    dr.Close();

                    string updateQuery = "UPDATE Evaluation SET obtained_marks = " + newValue1 + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Final'" + "and student_user_id = '" + user_id + "'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Decimal.Parse(newValue1) <= Decimal.Parse(Fw.Text))
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            MessageBox.Show("Please enter valid obtained marks");
                            Finalo.Text = oldval1;
                            return;
                        }
                    }
                }
            }
        }

        protected void ProjButton_Click(object sender, EventArgs e)
        {
            string newValue = Request.Form[Projecto.UniqueID];
            string oldval = Projecto.Text;
            Projecto.Text = newValue;

            // Retrieve the course, season, and year values from DropDownList1
            string value = Courses.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            int k = value.IndexOf('-', j + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, k - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id,section_name FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);
                    string section = dr.GetString(2);
                    string user_id = Students.SelectedValue;
                    dr.Close();

                    string updateQuery = "UPDATE Evaluation SET obtained_marks =" + newValue + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Project'" + "and student_user_id = '" + user_id + "'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Decimal.Parse(newValue) <= Decimal.Parse(Pw.Text))
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            MessageBox.Show("Please enter valid obtained marks");
                            Projecto.Text = oldval;
                            return;
                        }
                    }
                }

            }


        }

        protected void QButton_Click(object sender, EventArgs e)
        {
            string newValue1 = Request.Form[Qw.UniqueID];
            string oldval1 = Qw.Text;
            Qw.Text = newValue1;


            // Retrieve the course, season, and year values from DropDownList1
            string value = Courses.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            int k = value.IndexOf('-', j + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, k - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id,section_name FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);
                    string section = dr.GetString(2);
                    string user_id = Students.SelectedValue;
                    dr.Close();

                    string updateQuery = "UPDATE Evaluation SET total_marks = " + newValue1 + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Quiz'" + "and student_user_id = '" + user_id + "'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Decimal.Parse(newValue1) >= Decimal.Parse(Qo.Text))
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            MessageBox.Show("Please enter valid obtained marks");
                            Qw.Text = oldval1;
                            return;
                        }
                    }
                }
            }

        }

        protected void AButton_Click(object sender, EventArgs e)
        {

            string newValue1 = Request.Form[Ao.UniqueID];
            string oldval1 = Aw.Text;
            Aw.Text = newValue1;


            // Retrieve the course, season, and year values from DropDownList1
            string value = Courses.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            int k = value.IndexOf('-', j + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, k - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id,section_name FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);
                    string section = dr.GetString(2);
                    string user_id = Students.SelectedValue;
                    dr.Close();

                    string updateQuery = "UPDATE Evaluation SET total_marks = " + newValue1 + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Assignment'" + "and student_user_id = '" + user_id + "'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Decimal.Parse(newValue1) >= Decimal.Parse(Ao.Text))
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            MessageBox.Show("Please enter valid obtained marks");
                            Aw.Text = oldval1;
                            return;
                        }
                    }
                }
            }
        }

        protected void S1Button_Click(object sender, EventArgs e)
        {
            string newValue = Request.Form[S1w.UniqueID];
            string oldval = S1w.Text;
            S1w.Text = newValue;


            // Retrieve the course, season, and year values from DropDownList1
            string value = Courses.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            int k = value.IndexOf('-', j + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, k - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id,section_name FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);
                    string section = dr.GetString(2);
                    string user_id = Students.SelectedValue;
                    dr.Close();

                    string updateQuery = "UPDATE Evaluation SET total_marks = "+ newValue+ "WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Sessional-1'" + "and student_user_id = '" + user_id + "'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Decimal.Parse(newValue) >= Decimal.Parse(Sess1o.Text))
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            MessageBox.Show("Please enter valid obtained marks");
                            S1w.Text = oldval;
                            return;
                        }
                    }
                }
            }
        }

        protected void S2Button_Click(object sender, EventArgs e)
        {

            string newValue = Request.Form[S2w.UniqueID];
            string oldval = S2w.Text;
            S2w.Text = newValue;


            // Retrieve the course, season, and year values from DropDownList1
            string value = Courses.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            int k = value.IndexOf('-', j + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, k - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id,section_name FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);
                    string section = dr.GetString(2);
                    string user_id = Students.SelectedValue;
                    dr.Close();

                    string updateQuery = "UPDATE Evaluation SET total_marks = " + newValue + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Sessional-2'" + "and student_user_id = '" + user_id + "'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Decimal.Parse(newValue) >= Decimal.Parse(Sess2o.Text))
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            MessageBox.Show("Please enter valid obtained marks");
                            S2w.Text = oldval;
                            return;
                        }
                    }
                }
            }

        }

        protected void FButton_Click(object sender, EventArgs e)
        {
            string newValue = Request.Form[Fw.UniqueID];
            string oldval = Fw.Text;
            Fw.Text = newValue;


            // Retrieve the course, season, and year values from DropDownList1
            string value = Courses.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            int k = value.IndexOf('-', j + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, k - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id,section_name FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);
                    string section = dr.GetString(2);
                    string user_id = Students.SelectedValue;
                    dr.Close();

                    string updateQuery = "UPDATE Evaluation SET total_marks = " + newValue + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Final'" + "and student_user_id = '" + user_id + "'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Decimal.Parse(newValue) >= Decimal.Parse(Finalo.Text))
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            MessageBox.Show("Please enter valid obtained marks");
                            Fw.Text = oldval;
                            return;
                        }
                    }
                }
            }

        }

        protected void PButton_Click(object sender, EventArgs e)
        {
            string newValue = Request.Form[Pw.UniqueID];
            string oldval = Pw.Text;
            Pw.Text = newValue;

            // Retrieve the course, season, and year values from DropDownList1
            string value = Courses.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            int k = value.IndexOf('-', j + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, k - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id,section_name FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);
                    string section = dr.GetString(2);
                    string user_id = Students.SelectedValue;
                    dr.Close();

                    string updateQuery = "UPDATE Evaluation SET total_marks =" + newValue + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Project'" + "and student_user_id = '" + user_id + "'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Decimal.Parse(newValue) >= Decimal.Parse(Projecto.Text))
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            MessageBox.Show("Please enter valid obtained marks");
                            Pw.Text = oldval;
                            return;
                        }
                    }
                }
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Faculty.aspx");
        }
    }
}
