﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Web.UI;
using Label = System.Web.UI.WebControls.Label;
using CheckBox = System.Web.UI.WebControls.CheckBox;

namespace FlexClutch
{
    public partial class FeedbackReport : System.Web.UI.Page
    {

        List<Label> studentid = new List<Label>();
        List<Label> comments = new List<Label>();
        List<Label> feedscore = new List<Label>();
        List<Label> dates = new List<Label>();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                DropDownDataBindCourses();
                Course.EnableViewState = true;
            }

            UpdateArrays();
            UpdateTable();

        }

        protected void Course_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateArrays();
            UpdateTable();
        }

        protected void Return_Click(object sender, EventArgs e)
        {
            Response.Redirect("Faculty.aspx");
        }

        protected void DropDownDataBindCourses()
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True");
            conn.Open();

            SqlDataReader _reader = (SqlDataReader)Session["fr"];

            SqlCommand cm1;
            string query1 = "select course_name+'-'+season+'-'+year+'-' as CourseInfo from Faculty_Semester_Section_Course join Course on Faculty_Semester_Section_Course.course_id = Course.course_id join Semester on Faculty_Semester_Section_Course.semester_id = Semester.semester_id  where user_id = '" + _reader.GetString(0) + "'";
            cm1 = new SqlCommand(query1, conn);
            SqlDataReader dr1 = cm1.ExecuteReader();

            Course.DataSource = dr1;
            Course.DataTextField = "CourseInfo"; // Specify the display field name from your data source
            Course.DataValueField = "CourseInfo"; // Specify the value field name from your data source
            Course.DataBind();
            // Close the SqlDataReader
            dr1.Close();
        }

        protected void UpdateArrays()
        {
            // Clear the arrays to remove existing data
            studentid.Clear();
            comments.Clear();
            feedscore.Clear();
            dates.Clear();

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();

                SqlDataReader _reader = (SqlDataReader)Session["ar"];


                string value = Course.SelectedValue;
                int i = value.IndexOf('-');
                int j = value.IndexOf('-', i + 1);

                string course = value.Substring(0, i);
                string season = value.Substring(i + 1, j - (i + 1));
                string year = value.Substring(j + 1, value.Length - (j + 2));

                int cid;
                int semid;

                string query = "SELECT Course.course_id, Semester.semester_id FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = @course AND season = @season AND year = @year";
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@course", course);
                    cm.Parameters.AddWithValue("@season", season);
                    cm.Parameters.AddWithValue("@year", year);

                    SqlDataReader dr = cm.ExecuteReader();
                    if (dr.Read())
                    {
                        cid = dr.GetInt32(0);
                        semid = dr.GetInt32(1);
                        dr.Close();

                        string feedbackq = "Select student_user_id,comments,feedback_date,f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,1f4,f15,f16,f17,f18,f19,f20 from Feedback where semester_id=@semid and course_id = @cid";
                        using (SqlCommand cm1 = new SqlCommand(feedbackq, conn))
                        {
                            cm1.Parameters.AddWithValue("@semid", semid);
                            cm1.Parameters.AddWithValue("@cid", cid);

                            SqlDataReader feeds = cm1.ExecuteReader();

                            while (feeds.Read())
                            {
                                string studentId = feeds.GetString(0);
                                string comment = feeds.GetString(1);
                                string date = feeds.GetDateTime(2).ToString();

                                int x = 3;
                                int feedsco = 0;
                                while (x<23)
                                {
                                    feedsco += feeds.GetInt32(x++);
                                }

                                // Create labels for student ID and grade
                                Label lblStudentId = new Label();
                                lblStudentId.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + studentId + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; // Add 4 spaces between labels

                                Label lblName = new Label();
                                lblName.Text = comment + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

                                Label lbldate = new Label();
                                lbldate.Text = date;

                                Label feedscores = new Label();
                                feedscores.Text = feedsco.ToString()+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; 
                                // Add the labels to the lists
                                studentid.Add(lblStudentId);
                                comments.Add(lblName);
                                dates.Add(lbldate);
                                feedscore.Add(feedscores);

                            }
                        }
                    }
                }
            }
            // Update the placeholder table with the new array data
            UpdateTable();
        }

        protected void UpdateTable()
        {
            // Remove existing table from the placeholder control
            TablePlaceholder.Controls.Clear();

            // Create a new table
            Table table = new Table();

            // Add rows and cells using the updated array data
            for (int rowIndex = 0; rowIndex < studentid.Count; rowIndex++)
            {
                TableRow row = new TableRow();

                // Add label to the first column of the row
                TableCell labelCell = new TableCell();
                labelCell.Controls.Add(studentid[rowIndex]);
                row.Cells.Add(labelCell);

                // Add name to the second column of the row
                TableCell nameCell = new TableCell();
                nameCell.Controls.Add(feedscore[rowIndex]);
                row.Cells.Add(nameCell);

                // Add grade to the third column of the row
                TableCell gradeCell = new TableCell();
                gradeCell.Controls.Add(comments[rowIndex]);
                row.Cells.Add(gradeCell);

                // Add grade to the third column of the row
                TableCell dateCell = new TableCell();
                dateCell.Controls.Add(dates[rowIndex]);
                row.Cells.Add(dateCell);

                // Add the row to the table
                table.Rows.Add(row);
            }

            // Add the updated table to the placeholder control
            TablePlaceholder.Controls.Add(table);
        }
    }

}