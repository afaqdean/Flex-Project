﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Web.UI;
using Label = System.Web.UI.WebControls.Label;
using CheckBox = System.Web.UI.WebControls.CheckBox;


namespace FlexClutch
{
    public partial class Sections : System.Web.UI.Page
    {

        List<Label> studentidsdisplay = new List<Label>();
        List<string> studentids = new List<string>();
        List<Label> status = new List<Label>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                DropDownDataBindSemesters();
                DropDownDataBindCourses();
            }

            UpdateArrays();

        }

        protected void DropDownDataBindCourses()
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True");
            conn.Open();

            string semester = Semesters.SelectedValue;
            int i = semester.IndexOf('-');
            string season = semester.Substring(0, i);
            string year = semester.Substring(i + 1, semester.Length - (i + 1));

            SqlCommand cm1;
            string query1 = "SELECT semester_id from Semester where season=@season and year = @year;";
            cm1 = new SqlCommand(query1, conn);
            cm1.Parameters.AddWithValue("@season", season);
            cm1.Parameters.AddWithValue("@year", year);
            SqlDataReader dr1 = cm1.ExecuteReader();

            dr1.Read();

            int semid = dr1.GetInt32(0);

            dr1.Close();


            SqlCommand cm2 = new SqlCommand("SELECT course_name AS CourseInfo FROM OfferedCourses JOIN Course ON OfferedCourses.course_id = Course.course_id WHERE semester_id = @semid", conn);
            cm2.Parameters.AddWithValue("@semid", semid);
            SqlDataReader dr2 = cm2.ExecuteReader();

            Courses.DataSource = dr2;
            Courses.DataTextField = "CourseInfo";
            Courses.DataValueField = "CourseInfo";
            Courses.DataBind();
            // Close the SqlDataReader
            dr2.Close();
        }


        protected void DropDownDataBindSemesters()
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True");
            conn.Open();

            SqlCommand cm1;
            string query1 = "SELECT CONCAT(Semester.season, '-', Semester.year) AS CourseInfo from Semester;";
            cm1 = new SqlCommand(query1, conn);
            SqlDataReader dr1 = cm1.ExecuteReader();

            Semesters.DataSource = dr1;
            Semesters.DataTextField = "CourseInfo"; // Specify the display field name from your data source
            Semesters.DataValueField = "CourseInfo"; // Specify the value field name from your data source
            Semesters.DataBind();
            // Close the SqlDataReader
            dr1.Close();
        }

        protected void Semesters_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownDataBindCourses();
            UpdateArrays();
        }

        protected void Courses_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateArrays();

        }

        protected void UpdateArrays()
        {
            // Clear the arrays to remove existing data
            studentidsdisplay.Clear();
            status.Clear();
            studentids.Clear();


            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();

                string semester = Semesters.SelectedValue;
                int i = semester.IndexOf('-');

                string course = Courses.SelectedValue;
                string season = semester.Substring(0, i);
                string year = semester.Substring(i + 1, semester.Length - (i + 1));

                int cid = 0;
                int semid = 0;

                string query = "SELECT Course.course_id FROM OfferedCourses JOIN Course ON Course.course_id = OfferedCourses.course_id WHERE course_name = @course ";
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@course", course);

                    SqlDataReader dr = cm.ExecuteReader();
                    if (dr.Read())
                    {
                        cid = dr.GetInt32(0);

                        dr.Close();
                    }
                }

                string semQuery = "SELECT semester_id from Semester where season=@season and year = @year";
                using (SqlCommand cm1 = new SqlCommand(semQuery, conn))
                {
                    cm1.Parameters.AddWithValue("@season", season);
                    cm1.Parameters.AddWithValue("@year", year);

                    SqlDataReader dr = cm1.ExecuteReader();

                    if (dr.Read())
                    {
                        semid = dr.GetInt32(0);

                        dr.Close();
                    }


                }

                string studentQuery = "SELECT user_id,registered from AppliedforCourse where semester_id=@semid and course_id=@cid and registered='R'";
                using (SqlCommand cm1 = new SqlCommand(studentQuery, conn))
                {
                    cm1.Parameters.AddWithValue("@semid", semid);
                    cm1.Parameters.AddWithValue("@cid", cid);

                    SqlDataReader students = cm1.ExecuteReader();

                    while (students.Read())
                    {
                        string studentId = students.GetString(0);
                        string stat = students.GetString(1);

                        // Create labels for student ID and grade
                        Label lblStudentId = new Label();
                        lblStudentId.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + studentId + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; // Add 4 spaces between labels

                        Label lblStatus = new Label();
                        lblStatus.Text = stat;

                        // Add the labels to the lists
                        studentids.Add(students.GetString(0));
                        studentidsdisplay.Add(lblStudentId);
                        status.Add(lblStatus);
                    }
                }
            }

            UpdateTable();
        }

        protected void UpdateTable()
        {
            // Remove existing table from the placeholder control
            TablePlaceholder.Controls.Clear();

            // Create a new table
            Table table = new Table();

            // Add rows and cells using the updated array data
            for (int rowIndex = 0; rowIndex < studentids.Count; rowIndex++)
            {
                TableRow row = new TableRow();

                // Add label to the first column of the row
                TableCell labelCell = new TableCell();
                labelCell.Controls.Add(studentidsdisplay[rowIndex]);
                row.Cells.Add(labelCell);

                // Add name to the second column of the row
                TableCell nameCell = new TableCell();
                nameCell.Controls.Add(status[rowIndex]);
                row.Cells.Add(nameCell);

                // Add the row to the table
                table.Rows.Add(row);
            }

            TablePlaceholder.Controls.Add(table);
        }

        protected void GenerateSec_Click(object sender, EventArgs e)
        {
            char sectionname = 'A';

            int sectioncount = 0;
            if (studentids.Count % 50 == 0)
            {
                sectioncount = studentids.Count / 50;
            }
            else if (studentids.Count % 50 < 10 && studentids.Count > 0)
            {
                sectioncount = (studentids.Count / 40) + 1;
            }
            else if (studentids.Count % 50 >= 10)
            {
                sectioncount = (studentids.Count / 50) + 1;
            }
            int semid = 0; int cid = 0;

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();

                string value = Courses.SelectedValue;
                string sem = Semesters.SelectedValue;

                int i = sem.IndexOf('-');
                string season = sem.Substring(0, i);
                string year = sem.Substring(i + 1, sem.Length - (i + 1));

                string query2 = "SELECT course_id from Course where course_name=@course";
                using (SqlCommand cm = new SqlCommand(query2, conn))
                {
                    cm.Parameters.AddWithValue("@course", value);
                    SqlDataReader dr1 = cm.ExecuteReader();
                    dr1.Read();
                    cid = dr1.GetInt32(0);
                    dr1.Close();
                }

               
                string ifqueryc = "select * from Semester where season=@season and year = @year";
                using (SqlCommand cm = new SqlCommand(ifqueryc, conn))
                {
                    cm.Parameters.AddWithValue("@season", season);
                    cm.Parameters.AddWithValue("@year", year);
                    SqlDataReader dr = cm.ExecuteReader();

                    if (dr.HasRows)
                    {
                        dr.Read();
                        semid = dr.GetInt32(0);
                    }
                    dr.Close();
                }


                for (int y = 0; y < sectioncount; y++)
                {
                    string insertQuery = "INSERT INTO Section VALUES (@sectionname)";
                    using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@sectionname", sectionname.ToString());
                        cmd.ExecuteNonQuery();
                    }
                }

                sectionname++;
                   
                   

                sectionname = 'A';


                for (int x= 1; x <= sectioncount; x++)
                {
                    // Insert semester, course, and section into the table
                    string insertQuery = "INSERT INTO Semester_Section_Course VALUES (@semid, @cid, @sectionname)";
                    using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@semid",semid );
                        cmd.Parameters.AddWithValue("@cid", cid);
                        cmd.Parameters.AddWithValue("@sectionname", sectionname.ToString());

                        cmd.ExecuteNonQuery();
                    }

                    sectionname++; // Increment the section name for the next iteration
                }

                sectionname = 'A';


                int studentsPerSection = (int)Math.Ceiling((double)studentids.Count / sectioncount);
                int remainingStudents = studentids.Count % sectioncount;
                int sectionIndex = 0;

                for (int it = 0; it < studentids.Count; it++)
                {
                    // Insert student ID into the table
                    string insertQuery = "INSERT INTO Student_Semester_Section_Course VALUES (@userid, @semid, @cid, @sectionname, @grade)";
                    using (SqlCommand cm = new SqlCommand(insertQuery, conn))
                    {
                        cm.Parameters.AddWithValue("@userid", studentids[it]);
                        cm.Parameters.AddWithValue("@semid", semid);
                        cm.Parameters.AddWithValue("@cid", cid);
                        cm.Parameters.AddWithValue("@sectionname", sectionname.ToString());
                        cm.Parameters.AddWithValue("@grade", "I");

                        cm.ExecuteNonQuery();
                    }

                    // Increment section name after adding studentsPerSection students to each section
                    if ((it + 1) % studentsPerSection == 0)
                    {
                        sectionIndex++;

                        // Increment section name until the section count is reached
                        if (sectionIndex < sectioncount)
                        {
                            sectionname++;
                        }
                    }
                }

            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
         
            Response.Redirect("SectionReport.aspx");
        }
    }
}