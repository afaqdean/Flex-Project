﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Web.UI;
using Label = System.Web.UI.WebControls.Label;
using CheckBox = System.Web.UI.WebControls.CheckBox;

namespace FlexClutch
{
    public partial class SectionReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            string label = "";
         
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                List<string> sections = new List<string>();
                string query = "Select distinct section_name from Student_Semester_Section_Course";

                using (SqlCommand cm = new SqlCommand(query, conn))
                {

                    SqlDataReader dr = cm.ExecuteReader();
                    while (dr.Read())
                    {
                        sections.Add(dr.GetString(0));

                        
                    }
                    dr.Close();
                }

                for (int u = 0; u < sections.Count; u++)
                {
                    label += "Section " + sections[u] + ":\n";
                    string semQuery = "select Users.user_id, CONCAT(first_name,' ',last_name) from Users join Student_Semester_Section_Course on Users.user_id = Student_Semester_Section_Course.user_id where section_name = @sectionname order by USers.user_id;";
                    using (SqlCommand cm1 = new SqlCommand(semQuery, conn))
                    {
                        cm1.Parameters.AddWithValue("@sectionname", sections[u]);

                        SqlDataReader dr = cm1.ExecuteReader();

                        while (dr.Read())
                        {
                            label += dr.GetString(0) + "\t\t" + dr.GetString(1) +"\n";

                        }
                        dr.Close();

                        label += "\n";

                    }
                }

            }

            Label1.Text = label.Replace("\n", "<br />");

        }
    }
}