﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Web.UI;
using Label = System.Web.UI.WebControls.Label;
using CheckBox = System.Web.UI.WebControls.CheckBox;

namespace FlexClutch
{
    public partial class Academic : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void OfferedCourses_Click(object sender, EventArgs e)
        { 
           
            Response.Redirect("OfferedCourses.aspx");

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("AllocSections.aspx");

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("AllocateCourses.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }
    }
}