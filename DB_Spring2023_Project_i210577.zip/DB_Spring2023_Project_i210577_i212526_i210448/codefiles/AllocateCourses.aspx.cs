﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Web.UI;
using Label = System.Web.UI.WebControls.Label;
using CheckBox = System.Web.UI.WebControls.CheckBox;

namespace FlexClutch
{
    public partial class AllocateCourses : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                DropDownDataBindSemesters();
                DropDownDataBindCourses();
            }

        }

        protected void Semesters_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownDataBindCourses();
        }

        protected void OfferedCourses_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void DropDownDataBindSemesters()
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True");
            conn.Open();

            SqlCommand cm1;
            string query1 = "SELECT CONCAT(Semester.season, '-', Semester.year) AS CourseInfo from Semester;";
            cm1 = new SqlCommand(query1, conn);
            SqlDataReader dr1 = cm1.ExecuteReader();

            Semesters.DataSource = dr1;
            Semesters.DataTextField = "CourseInfo"; // Specify the display field name from your data source
            Semesters.DataValueField = "CourseInfo"; // Specify the value field name from your data source
            Semesters.DataBind();
            // Close the SqlDataReader
            dr1.Close();
        }

        protected void DropDownDataBindCourses()
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True");
            conn.Open();

            string semester = Semesters.SelectedValue;
            int i = semester.IndexOf('-');
            string season = semester.Substring(0, i);
            string year = semester.Substring(i + 1, semester.Length - (i + 1));

            SqlCommand cm1;
            string query1 = "SELECT semester_id from Semester where season=@season and year = @year;";
            cm1 = new SqlCommand(query1, conn);
            cm1.Parameters.AddWithValue("@season", season);
            cm1.Parameters.AddWithValue("@year", year);
            SqlDataReader dr1 = cm1.ExecuteReader();

            dr1.Read();

            int semid = dr1.GetInt32(0);

            dr1.Close();


            SqlCommand cm2 = new SqlCommand("SELECT course_name AS CourseInfo FROM OfferedCourses JOIN Course ON OfferedCourses.course_id = Course.course_id WHERE semester_id = @semid", conn);
            cm2.Parameters.AddWithValue("@semid", semid);
            SqlDataReader dr2 = cm2.ExecuteReader();

            OfferedCourses.DataSource = dr2;
            OfferedCourses.DataTextField = "CourseInfo";
            OfferedCourses.DataValueField = "CourseInfo";
            OfferedCourses.DataBind();
            // Close the SqlDataReader
            dr2.Close();
        }

        protected void Instructor_Click(object sender, EventArgs e)
        {

            try
            {
                using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
                {
                    conn.Open();
                    string value = OfferedCourses.SelectedValue;
                    string semester = Semesters.SelectedValue;
                    int i = semester.IndexOf('-');
                    string season = semester.Substring(0, i);
                    string year = semester.Substring(i + 1, semester.Length - (i + 1));

                    string course = value;

                    string section = Request.Form[Section.UniqueID];
                    string instruc = Request.Form[Inst.UniqueID];

                    int cid;
                    int semid = 0;

                    string query1 = "SELECT semester_id from Semester where season=@season and year = @year;";
                    using (SqlCommand cm = new SqlCommand(query1, conn))
                    {
                        cm.Parameters.AddWithValue("@season", season);
                        cm.Parameters.AddWithValue("@year", year);
                        SqlDataReader dr1 = cm.ExecuteReader();
                        dr1.Read();
                        semid = dr1.GetInt32(0);
                        dr1.Close();
                    }


                    string query2 = "SELECT course_id from Course where course_name=@course";
                    using (SqlCommand cm = new SqlCommand(query2, conn))
                    {
                        cm.Parameters.AddWithValue("@course", course);
                        SqlDataReader dr1 = cm.ExecuteReader();
                        dr1.Read();
                        cid = dr1.GetInt32(0);
                        dr1.Close();
                    }


                    string ifteach = "Select Count(distinct(course_id)) from Faculty_Semester_Section_Course where semester_id =@semid and user_id=@userid";
                    using (SqlCommand cm = new SqlCommand(ifteach, conn))
                    {
                        cm.Parameters.AddWithValue("@semid", semid);
                        cm.Parameters.AddWithValue("@userid", instruc);
                        SqlDataReader dr1 = cm.ExecuteReader();
                        dr1.Read();
                        int count = dr1.GetInt32(0);

                        if (count == 3)
                        {
                            MessageBox.Show("Instructor already teaches maximum no of courses.");
                            return;
                        }
                        dr1.Close();
                    }

                    string add = "Insert into Faculty_Semester_Section_Course Values(@userid, @semid, @cid, @section)";
                    using (SqlCommand cm = new SqlCommand(add, conn))
                    {
                        cm.Parameters.AddWithValue("@cid", cid);
                        cm.Parameters.AddWithValue("@semid", semid);
                        cm.Parameters.AddWithValue("@userid", instruc);
                        cm.Parameters.AddWithValue("@section", section);

                        cm.ExecuteNonQuery();
                    }

                    MessageBox.Show( course+" allocated to" + instruc);
                }
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) // Check if the exception is caused by a duplicate key violation
                {
                    MessageBox.Show("Instructor already allocated");
                }
                else
                {
                    // Handle other types of SQL exceptions if needed
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }

  
        }

        protected void Coord_Click(object sender, EventArgs e)
        {

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();

                string value = OfferedCourses.SelectedValue;
                string coordid = Request.Form[CoOrdi.UniqueID];
                int cid = 0;
                string query2 = "SELECT course_id from Course where course_name=@course";
                using (SqlCommand cm = new SqlCommand(query2, conn))
                {
                    cm.Parameters.AddWithValue("@course", value);
                    SqlDataReader dr1 = cm.ExecuteReader();
                    dr1.Read();
                    cid = dr1.GetInt32(0);
                    dr1.Close();
                }

                string update = "UPDATE Course SET coordinator_id = @user_id where course_name = @course";
                using (SqlCommand cm = new SqlCommand(update, conn))
                {
                    cm.Parameters.AddWithValue("@course", value);
                    cm.Parameters.AddWithValue("@user_id", coordid);
                    cm.ExecuteNonQuery();
                }

                MessageBox.Show(value + " allocated to " + coordid);

            }
        }

        protected void Return_Click(object sender, EventArgs e)
        {
            Response.Redirect("Academic.aspx");
        }

        protected void GenRep_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                string message = "Allocated Courses Report: \n";
               
                string ifqueryc = "Select course_code,course_name,credit_hours,coordinator_id,STRING_AGG(section_name,','),STRING_AGG(user_id,',') from Course join Faculty_Semester_Section_Course on Course.course_id =Faculty_Semester_Section_Course.course_id where Course.course_id!=0 group by course_code,course_name,credit_hours,coordinator_id;";
                using (SqlCommand cm = new SqlCommand(ifqueryc, conn))
                {
                    SqlDataReader dr = cm.ExecuteReader();
                    
                    //string m = "Course Code:" + "\t" + "Course Name:" + "\t" + "Credit Hours: " + "\t" + "Co-ordinator:" + "\t"+ "Sections: " + "\t" + "Instructors:"+"\t\n";
                    //message += m;
                    while (dr.Read())
                    {
                        message = message + dr.GetString(0) + "\t" + dr.GetString(1) + "\t" + dr.GetInt32(2).ToString() + "\t" + dr.GetString(3) + "\t" + dr.GetString(4) + "\t\n";
                    }

                    dr.Close();
                }

                MessageBox.Show(message);

            }
        }
    }
}