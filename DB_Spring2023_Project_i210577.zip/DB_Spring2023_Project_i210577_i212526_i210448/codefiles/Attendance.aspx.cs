﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Web.UI;
using Label = System.Web.UI.WebControls.Label;
using CheckBox = System.Web.UI.WebControls.CheckBox;

namespace FlexClutch
{


    public partial class Attendance : System.Web.UI.Page
    {
        List<Label> labels = new List<Label>();
        List<Label> names = new List<Label>();
        List<CheckBox> checkboxList = new List<CheckBox>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                DropDownDataBindCourses();
                DropDownDataBindSections();
                DropDownList1.EnableViewState = true;
                DropDownList2.EnableViewState = true;
            }

            UpdateArrays();
            UpdateTable();
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownDataBindSections();
            UpdateArrays();
            UpdateTable();
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateArrays();
            UpdateTable();
        }

        protected void DropDownDataBindCourses()
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True");
            conn.Open();

            SqlDataReader _reader = (SqlDataReader)Session["ar"];

            SqlCommand cm1;
            string query1 = "select course_name+'-'+season+'-'+year+'-' as CourseInfo from Faculty_Semester_Section_Course join Course on Faculty_Semester_Section_Course.course_id = Course.course_id join Semester on Faculty_Semester_Section_Course.semester_id = Semester.semester_id  where user_id = '" + _reader.GetString(0) + "'";
            cm1 = new SqlCommand(query1, conn);
            SqlDataReader dr1 = cm1.ExecuteReader();

            DropDownList2.DataSource = dr1;
            DropDownList2.DataTextField = "CourseInfo"; // Specify the display field name from your data source
            DropDownList2.DataValueField = "CourseInfo"; // Specify the value field name from your data source
            DropDownList2.DataBind();
            // Close the SqlDataReader
            dr1.Close();
        }

        protected void DropDownDataBindSections()
        {
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();

                SqlDataReader _reader = (SqlDataReader)Session["ar"];

                string value = DropDownList2.SelectedValue;
                int i = value.IndexOf('-');
                int j = value.IndexOf('-', i + 1);

                string course = value.Substring(0, i);
                string season = value.Substring(i + 1, j - (i + 1));
                string year = value.Substring(j + 1, value.Length - (j + 2));

                int cid;
                int semid;

                string query = "SELECT Course.course_id, Semester.semester_id FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = @course AND season = @season AND year = @year";
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@course", course);
                    cm.Parameters.AddWithValue("@season", season);
                    cm.Parameters.AddWithValue("@year", year);

                    SqlDataReader dr = cm.ExecuteReader();
                    if (dr.Read())
                    {
                        cid = dr.GetInt32(0);
                        semid = dr.GetInt32(1);
                        dr.Close();

                        string sectionQuery = "SELECT section_name FROM Faculty_Semester_Section_Course WHERE semester_id = " + semid.ToString() + " AND course_id = " + cid.ToString() + " AND user_id = '" + _reader.GetString(0) + "'";
                        using (SqlCommand cm1 = new SqlCommand(sectionQuery, conn))
                        {
                            SqlDataReader dr1 = cm1.ExecuteReader();

                            List<string> sections = new List<string>();
                            while (dr1.Read())
                            {
                                string sectionId = dr1.GetString(0);
                                sections.Add(sectionId);
                            }

                            DropDownList1.DataSource = sections;
                            DropDownList1.DataBind();

                            // Close the SqlDataReader
                            dr1.Close();
                        }
                    }
                }
            }
        }

        protected void UpdateArrays()
        {
            // Clear the arrays to remove existing data
            labels.Clear();
            names.Clear();
            checkboxList.Clear();

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();

                SqlDataReader _reader = (SqlDataReader)Session["ar"];


                string value = DropDownList2.SelectedValue;
                string section = DropDownList1.SelectedValue;
                int i = value.IndexOf('-');
                int j = value.IndexOf('-', i + 1);

                string course = value.Substring(0, i);
                string season = value.Substring(i + 1, j - (i + 1));
                string year = value.Substring(j + 1, value.Length - (j + 2));

                int cid;
                int semid;

                string query = "SELECT Course.course_id, Semester.semester_id FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = @course AND season = @season AND year = @year";
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@course", course);
                    cm.Parameters.AddWithValue("@season", season);
                    cm.Parameters.AddWithValue("@year", year);

                    SqlDataReader dr = cm.ExecuteReader();
                    if (dr.Read())
                    {
                        cid = dr.GetInt32(0);
                        semid = dr.GetInt32(1);
                        dr.Close();

                        string studentQuery = "SELECT Users.user_id,first_name,last_name FROM Student_Semester_Section_Course join Users on Student_Semester_Section_Course.user_id = Users.user_id WHERE semester_id = @semid AND course_id = @cid AND section_name = @section";
                        using (SqlCommand cm1 = new SqlCommand(studentQuery, conn))
                        {
                            cm1.Parameters.AddWithValue("@semid", semid);
                            cm1.Parameters.AddWithValue("@cid", cid);
                            cm1.Parameters.AddWithValue("@section", section);
                            SqlDataReader students = cm1.ExecuteReader();


                            while (students.Read())
                            {
                                string studentId = students.GetString(0);
                                string name = students.GetString(1) + " " + students.GetString(2);

                                // Create labels for student ID and grade
                                Label lblStudentId = new Label();
                                lblStudentId.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + studentId + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; // Add 4 spaces between labels

                                Label lblName = new Label();
                                lblName.Text = name + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

                                CheckBox lbl = new CheckBox();

                                // Add the labels to the lists
                                labels.Add(lblStudentId);
                                checkboxList.Add(lbl);
                                names.Add(lblName);
                            }
                        }
                    }
                }
            }
            // Update the placeholder table with the new array data
            UpdateTable();
        }

        protected void UpdateTable()
        {
            // Remove existing table from the placeholder control
            TablePlaceholder.Controls.Clear();

            // Create a new table
            Table table = new Table();

            // Add rows and cells using the updated array data
            for (int rowIndex = 0; rowIndex < labels.Count; rowIndex++)
            {
                TableRow row = new TableRow();

                // Add label to the first column of the row
                TableCell labelCell = new TableCell();
                labelCell.Controls.Add(labels[rowIndex]);
                row.Cells.Add(labelCell);

                // Add name to the second column of the row
                TableCell nameCell = new TableCell();
                nameCell.Controls.Add(names[rowIndex]);
                row.Cells.Add(nameCell);

                // Add grade to the third column of the row
                TableCell gradeCell = new TableCell();
                gradeCell.Controls.Add(checkboxList[rowIndex]);
                row.Cells.Add(gradeCell);

                // Add the row to the table
                table.Rows.Add(row);
            }

            // Add the updated table to the placeholder control
            TablePlaceholder.Controls.Add(table);
        }

        protected void Return_Click(object sender, EventArgs e)
        {
            Response.Redirect("Faculty.aspx");
        }

        protected void AddLect_Click(object sender, EventArgs e)
        {
            string date = Request.Form[Date.UniqueID];
            string roomno = Request.Form[room.UniqueID];
            string durationtime = Request.Form[duration.UniqueID];
            int lectid = 0;

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();


                string value = DropDownList2.SelectedValue;
                string section = DropDownList1.SelectedValue;
                int i = value.IndexOf('-');
                int j = value.IndexOf('-', i + 1);

                string course = value.Substring(0, i);
                string season = value.Substring(i + 1, j - (i + 1));
                string year = value.Substring(j + 1, value.Length - (j + 2));

                int cid;
                int semid;

                string query = "SELECT Course.course_id, Semester.semester_id FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = @course AND season = @season AND year = @year";
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@course", course);
                    cm.Parameters.AddWithValue("@season", season);
                    cm.Parameters.AddWithValue("@year", year);

                    SqlDataReader dr = cm.ExecuteReader();
                    dr.Read();

                    cid = dr.GetInt32(0);
                    semid = dr.GetInt32(1);
                    dr.Close();
                }

                string lectidquery = "Select Count(*) from Lecture";

                //current lecture id
                using (SqlCommand cm1 = new SqlCommand(lectidquery, conn))
                {
                    SqlDataReader dr = cm1.ExecuteReader();
                    if (dr.Read())
                    {
                        lectid = dr.GetInt32(0);
                    }

                    dr.Close();

                }

                //Insert lecture
                string addlecquery = "INSERT INTO Lecture (lecture_id, lecture_date, duration,room,semester_id, course_id, section_name) VALUES ( @lectid,@date, @durationtime, @roomno, @semid, @cid, @section)";

                using (SqlCommand cm1 = new SqlCommand(addlecquery, conn))
                {
                    cm1.Parameters.AddWithValue("@date", date);
                    cm1.Parameters.AddWithValue("@roomno", roomno);
                    cm1.Parameters.AddWithValue("@durationtime", durationtime);
                    cm1.Parameters.AddWithValue("@lectid", lectid);
                    cm1.Parameters.AddWithValue("@semid", semid);
                    cm1.Parameters.AddWithValue("@cid", cid);
                    cm1.Parameters.AddWithValue("@section", section);

                    cm1.ExecuteNonQuery();
                }

                List<string> studentids = new List<string>();

                string studentQuery = "SELECT user_id FROM Student_Semester_Section_Course WHERE semester_id = @semid AND course_id = @cid AND section_name = @section";
                using (SqlCommand cm1 = new SqlCommand(studentQuery, conn))
                {
                    cm1.Parameters.AddWithValue("@semid", semid);
                    cm1.Parameters.AddWithValue("@cid", cid);
                    cm1.Parameters.AddWithValue("@section", section);
                    SqlDataReader students = cm1.ExecuteReader();


                    while (students.Read())
                    {
                        studentids.Add(students.GetString(0));
                    }
                    students.Close();
                }

                string addlectosquery = "INSERT INTO Student_Takes_Lecture (user_id, lecture_id) VALUES (@studentid, @lectid)";

                using (SqlCommand cm2 = new SqlCommand(addlectosquery, conn))
                {
                    cm2.Parameters.AddWithValue("@lectid", lectid);

                    for (int it = 0; it < studentids.Count; it++)
                    {
                        if (checkboxList[it].Checked)
                        {
                            cm2.Parameters.AddWithValue("@studentid", studentids[it]);
                            cm2.ExecuteNonQuery();
                            cm2.Parameters.RemoveAt("@studentid");
                        }
                    }
                }
            }

        }
}   }