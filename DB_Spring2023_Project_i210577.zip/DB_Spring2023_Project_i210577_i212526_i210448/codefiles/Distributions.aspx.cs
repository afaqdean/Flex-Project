﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace FlexClutch
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //   SqlDataReader _reader = (SqlDataReader)Session["cr"];

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();

                if (!Page.IsPostBack)
                {
                    BindDropDownData();
                    DropDownList1.EnableViewState = true;

                }

                string value = DropDownList1.SelectedValue;
                string iv;
                int i = DropDownList1.SelectedValue.IndexOf('-');
                int j = DropDownList1.SelectedValue.IndexOf('-', i + 1); ;

                string course = value.Substring(0, i);
                string season = value.Substring(i + 1, j - (i + 1));
                string year = value.Substring(j + 1, value.Length - (j + 1));

                string query1 = "select Course.course_id,Semester.semester_id from Course join Semester_Section_Course on Course.course_id =Semester_Section_Course.course_id join Semester on Semester_Section_Course.semester_id =Semester.semester_id where course_name = '" + course + "' and season= '" + season + "' and year='" + year + "'";

                using (SqlCommand cm1 = new SqlCommand(query1, conn))
                {
                    //courses taught by faculty

                    SqlDataReader dr1 = cm1.ExecuteReader();
                    dr1.Read();

                    int cid = dr1.GetInt32(0);
                    int semid = dr1.GetInt32(1);
                    dr1.Close();

                    SqlDataReader dr3;

                    string query3 = "select weightage, type from Distribution_Course where course_id = " + cid.ToString() + " and semester_id = " + semid.ToString(); //courses taught by faculty
                    using (SqlCommand cm3 = new SqlCommand(query3, conn))
                    {
                        dr3 = cm3.ExecuteReader();

                        while (dr3.Read())
                        {
                            // MessageBox.Show(dr3.GetString(1));
                            if (String.Equals(dr3.GetString(1), "Quiz"))
                            {
                                Qw.Text = dr3.GetDecimal(0).ToString();
                                iv = Qw.Text;
                            }
                            if (String.Equals(dr3.GetString(1), "Assignment"))
                            {
                                Aw.Text = dr3.GetDecimal(0).ToString();
                            }
                            if (String.Equals(dr3.GetString(1), "Sessional-1"))
                            {
                                S1w.Text = dr3.GetDecimal(0).ToString();
                            }
                            if (String.Equals(dr3.GetString(1), "Sessional-2"))
                            {
                                S2w.Text = dr3.GetDecimal(0).ToString();

                            }
                            if (String.Equals(dr3.GetString(1), "Final"))
                            {
                                Fw.Text = dr3.GetDecimal(0).ToString();
                            }
                            if (String.Equals(dr3.GetString(1), "Project"))
                            {
                                Pw.Text = dr3.GetDecimal(0).ToString();
                            }
                        }

                        if (Qw.Text == "")
                        {
                            Quiz.Visible = false;
                            Qw.Visible = false;
                            QwButton.Visible = false;
                        }
                        if (Aw.Text == "")
                        {
                            Assignment.Visible = false;
                            Aw.Visible = false;
                            AwButton.Visible = false;
                        }
                        if (S1w.Text == "")
                        {
                            Sess1.Visible = false;
                            S1w.Visible = false;
                            Sess1Button.Visible = false;
                        }
                        if (S2w.Text == "")
                        {
                            Sess2.Visible = false;
                            S2w.Visible = false;
                            Sess2Button.Visible = false;
                        }
                        if (Fw.Text == "")
                        {
                            Final.Visible = false;
                            Fw.Visible = false;
                            FinalButton.Visible = false;
                        }
                        if (Pw.Text == "")
                        {
                            Project.Visible = false;
                            Pw.Visible = false;
                            ProjButton.Visible = false;
                        }
                    }
                }
            }

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True");
            conn.Open();

            string value = DropDownList1.SelectedValue;

            int i = DropDownList1.SelectedValue.IndexOf('-');
            int j = DropDownList1.SelectedValue.IndexOf('-', i + 1); ;

            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, value.Length - (j + 1));


            string query1 = "select Course.course_id,Semester.semester_id from Course join Semester_Section_Course on Course.course_id =Semester_Section_Course.course_id join Semester on Semester_Section_Course.semester_id =Semester.semester_id where course_name = '" + course + "' and season= '" + season + "' and year='" + year + "'"; //courses taught by faculty
            using (SqlCommand cm1 = new SqlCommand(query1, conn))
            {
                SqlDataReader dr1 = cm1.ExecuteReader();
                dr1.Read();

                int cid = dr1.GetInt32(0);
                int semid = dr1.GetInt32(1);

                dr1.Close();
                string query3 = "select weightage, type from Distribution_Course where course_id = " + cid.ToString() + " and semester_id = " + semid.ToString(); //courses taught by faculty
                using (SqlCommand cm3 = new SqlCommand(query3, conn))
                {
                    SqlDataReader dr3 = cm3.ExecuteReader();

                    if (!dr3.HasRows)
                    {
                        MessageBox.Show("There are no distributions set for this course");
                        Qw.Text = "";
                        Pw.Text = "";
                        Fw.Text = "";
                        Aw.Text = "";
                        S1w.Text = "";
                        S2w.Text = "";

                        if (Qw.Text == "")
                        {
                            Quiz.Visible = false;
                            Qw.Visible = false;
                            QwButton.Visible = false;
                        }
                        if (Aw.Text == "")
                        {
                            Assignment.Visible = false;
                            Aw.Visible = false;
                            AwButton.Visible = false;
                        }
                        if (S1w.Text == "")
                        {
                            Sess1.Visible = false;
                            S1w.Visible = false;
                            Sess1Button.Visible = false;
                        }
                        if (S2w.Text == "")
                        {
                            Sess2.Visible = false;
                            S2w.Visible = false;
                            Sess2Button.Visible = false;
                        }
                        if (Fw.Text == "")
                        {
                            Final.Visible = false;
                            Fw.Visible = false;
                            FinalButton.Visible = false;
                        }
                        if (Pw.Text == "")
                        {
                            Project.Visible = false;
                            Pw.Visible = false;
                            ProjButton.Visible = false;
                        }

                    }

                    while (dr3.Read())
                    {
                        OpenTexts();
                        // MessageBox.Show(dr3.GetString(1));
                        if (String.Equals(dr3.GetString(1), "Quiz"))
                        {
                            Qw.Text = dr3.GetDecimal(0).ToString();
                        }
                        if (String.Equals(dr3.GetString(1), "Assignment"))
                        {
                            Aw.Text = dr3.GetDecimal(0).ToString();
                        }
                        if (String.Equals(dr3.GetString(1), "Sessional-1"))
                        {
                            S1w.Text = dr3.GetDecimal(0).ToString();
                        }
                        if (String.Equals(dr3.GetString(1), "Sessional-2"))
                        {
                            S2w.Text = dr3.GetDecimal(0).ToString();

                        }
                        if (String.Equals(dr3.GetString(1), "Final"))
                        {
                            Fw.Text = dr3.GetDecimal(0).ToString();
                        }
                        if (String.Equals(dr3.GetString(1), "Project"))
                        {
                            Pw.Text = dr3.GetDecimal(0).ToString();
                        }
                    }

                    if (Qw.Text == "")
                    {
                        Quiz.Visible = false;
                        Qw.Visible = false;
                        QwButton.Visible = false;
                    }
                    if (Aw.Text == "")
                    {
                        Assignment.Visible = false;
                        Aw.Visible = false;
                        AwButton.Visible = false;
                    }
                    if (S1w.Text == "")
                    {
                        Sess1.Visible = false;
                        S1w.Visible = false;
                        Sess1Button.Visible = false;
                    }
                    if (S2w.Text == "")
                    {
                        Sess2.Visible = false;
                        S2w.Visible = false;
                        Sess2Button.Visible = false;
                    }
                    if (Fw.Text == "")
                    {
                        Final.Visible = false;
                        Fw.Visible = false;
                        FinalButton.Visible = false;
                    }
                    if (Pw.Text == "")
                    {
                        Project.Visible = false;
                        Pw.Visible = false;
                        ProjButton.Visible = false;
                    }
                }
            }
        }



        protected void BindDropDownData()
        {

            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True");
            conn.Open();

            SqlDataReader _reader = (SqlDataReader)Session["cr"];

            SqlCommand cm1;
            string query1 = "select course_name+'-'+season+'-'+year as CourseInfo from Faculty_Semester_Section_Course join Course on Faculty_Semester_Section_Course.course_id = Course.course_id join Semester on Faculty_Semester_Section_Course.semester_id = Semester.semester_id  where user_id = '" + _reader.GetString(0) + "'";
            cm1 = new SqlCommand(query1, conn);
            SqlDataReader dr1 = cm1.ExecuteReader();

            DropDownList1.DataSource = dr1;
            DropDownList1.DataTextField = "CourseInfo"; // Specify the display field name from your data source
            DropDownList1.DataValueField = "CourseInfo"; // Specify the value field name from your data source
            DropDownList1.DataBind();
            // Close the SqlDataReader
            dr1.Close();

        }
        protected void QwButton_Click(object sender, EventArgs e)
        {
            string newValue = Request.Form[Qw.UniqueID];
            string oldval = Qw.Text;
            Qw.Text = newValue;

            // Retrieve the course, season, and year values from DropDownList1
            string value = DropDownList1.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, value.Length - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);

                    dr.Close();

                    string updateQuery = "UPDATE Distribution_Course SET weightage = " + newValue + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Quiz'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Valid())
                        {
                            updateCmd.ExecuteNonQuery();

                            Qw.Text = oldval;
                        }
                        else {
                            Qw.Text = oldval;
                            return; }
                    }
                }
            }

        }

        protected void AwButton_Click(object sender, EventArgs e)
        {
            string newValue = Request.Form[Aw.UniqueID];
            string oldval = Aw.Text;
            Aw.Text = newValue;

            // Retrieve the course, season, and year values from DropDownList1
            string value = DropDownList1.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, value.Length - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);

                  
                    dr.Close();

                    string updateQuery = "UPDATE Distribution_Course SET weightage = " + newValue + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Assignment'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Valid())
                        {
                            updateCmd.ExecuteNonQuery();

                         
                        }
                        else
                        {
                            Aw.Text = oldval;
                            return; }
                    }
                }
            }
        }

        protected void Sess1Button_Click(object sender, EventArgs e)
        {
            string newValue = Request.Form[S1w.UniqueID];
            string oldval = S1w.Text;
            S1w.Text = newValue;


            // Retrieve the course, season, and year values from DropDownList1
            string value = DropDownList1.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, value.Length - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);

                   
                    dr.Close();

                    string updateQuery = "UPDATE Distribution_Course SET weightage = " + newValue + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Sessional-1'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Valid())
                        {
                            updateCmd.ExecuteNonQuery();

                           
                        }
                        else
                        {
                            S2w.Text = oldval;
                            return; }
                    }
                }
            }
        }

        protected void Sess2Button_Click(object sender, EventArgs e)
        {

            string newValue = Request.Form[S2w.UniqueID];
            string oldval = S2w.Text;
            S2w.Text = newValue;


            // Retrieve the course, season, and year values from DropDownList1
            string value = DropDownList1.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, value.Length - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);

                   
                    dr.Close();

                    string updateQuery = "UPDATE Distribution_Course SET weightage = " + newValue + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Sessional-2'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Valid())
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            S2w.Text = oldval;
                            return; }
                    }
                }
            }
        }

        protected void FinalButton_Click(object sender, EventArgs e)
        {

            string newValue = Request.Form[Fw.UniqueID];
            string oldval = Fw.Text;
            Fw.Text = newValue;


            // Retrieve the course, season, and year values from DropDownList1
            string value = DropDownList1.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, value.Length - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);

                    
                    dr.Close();

                    string updateQuery = "UPDATE Distribution_Course SET weightage = " + newValue + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Final'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Valid())
                        {
                            updateCmd.ExecuteNonQuery();
                        }
                        else
                        {
                            Fw.Text = oldval;
                            return; 
                        }
                    }
                }
            }
        }

        protected void ProjButton_Click(object sender, EventArgs e)
        {
            string newValue = Request.Form[Pw.UniqueID];
            string oldval = Pw.Text;
            Pw.Text = newValue;


            // Retrieve the course, season, and year values from DropDownList1
            string value = DropDownList1.SelectedValue;
            int i = value.IndexOf('-');
            int j = value.IndexOf('-', i + 1);
            string course = value.Substring(0, i);
            string season = value.Substring(i + 1, j - (i + 1));
            string year = value.Substring(j + 1, value.Length - (j + 1));
            string query1 = "SELECT Course.course_id, Semester.semester_id FROM Course JOIN Semester_Section_Course ON Course.course_id = Semester_Section_Course.course_id JOIN Semester ON Semester_Section_Course.semester_id = Semester.semester_id WHERE course_name = '" + course + "' AND season = '" + season + "' AND year = '" + year + "'";

            // Create a new SqlConnection and SqlCommand
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query1, conn))
                {
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    int cid = dr.GetInt32(0);
                    int semid = dr.GetInt32(1);

                   
                    dr.Close();

                    string updateQuery = "UPDATE Distribution_Course SET weightage = " + newValue + " WHERE course_id = " + cid.ToString() + " AND semester_id =" + semid.ToString() + "AND type = 'Project'";

                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                    {
                        if (Valid())
                        {
                            updateCmd.ExecuteNonQuery();
                           
                        }
                        else 
                        {
                            Pw.Text = oldval;
                            return;
                        }
                    }
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Faculty.aspx");
        }

        protected bool Valid()
        {
            System.Web.UI.WebControls.TextBox[] textBoxes = new System.Web.UI.WebControls.TextBox[6]; // Replace '4' with the actual number of text boxes you have

            textBoxes[0] = Qw;
            textBoxes[1] = Aw;
            textBoxes[2] = Fw;
            textBoxes[3] = S1w;
            textBoxes[4] = S2w;
            textBoxes[5] = Pw;

            int sum = 0;
            foreach (System.Web.UI.WebControls.TextBox textBox in textBoxes)
            {
                int value;
                if (int.TryParse(textBox.Text, out value))
                {
                    sum += value;
                }
                else if (textBox.Text == "")
                {
                    sum += 0;
                }
            }

            return sum == 100;

        }

        protected void OpenTexts()
        {
            if (Qw.Text != "")
            {
                Quiz.Visible = true;
                Qw.Visible = true;
                QwButton.Visible = true;
            }
            if (Aw.Text != "")
            {
                Assignment.Visible = true;
                Aw.Visible = true;
                AwButton.Visible = true;
            }
            if (S1w.Text != "")
            {
                Sess1.Visible = true;
                S1w.Visible = true;
                Sess1Button.Visible = true;
            }
            if (S2w.Text != "")
            {
                Sess2.Visible = true;
                S2w.Visible = true;
                Sess2Button.Visible = true;
            }
            if (Fw.Text != "")
            {
                Final.Visible = true;
                Fw.Visible = true;
                FinalButton.Visible = true;
            }
            if (Pw.Text != "")
            {
                Project.Visible = true;
                Pw.Visible = true;
                ProjButton.Visible = true;
            }

        }
    }

 

}