﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Web.UI;
using Label = System.Web.UI.WebControls.Label;
using CheckBox = System.Web.UI.WebControls.CheckBox;


namespace FlexClutch
{

    public partial class AllocSections : System.Web.UI.Page
    {
        List<Label> studentids = new List<Label>();
        List<Label> status = new List<Label>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                DropDownDataBindSemesters();
                DropDownDataBindCourses();
            }

            UpdateArrays();

        }

        protected void DropDownDataBindCourses()
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True");
            conn.Open();

            string semester = Semesters.SelectedValue;
            int i = semester.IndexOf('-');
            string season = semester.Substring(0, i);
            string year = semester.Substring(i + 1, semester.Length - (i + 1));

            SqlCommand cm1;
            string query1 = "SELECT semester_id from Semester where season=@season and year = @year;";
            cm1 = new SqlCommand(query1, conn);
            cm1.Parameters.AddWithValue("@season", season);
            cm1.Parameters.AddWithValue("@year", year);
            SqlDataReader dr1 = cm1.ExecuteReader();

            dr1.Read();

            int semid = dr1.GetInt32(0);

            dr1.Close();


            SqlCommand cm2 = new SqlCommand("SELECT course_name AS CourseInfo FROM OfferedCourses JOIN Course ON OfferedCourses.course_id = Course.course_id WHERE semester_id = @semid", conn);
            cm2.Parameters.AddWithValue("@semid", semid);
            SqlDataReader dr2 = cm2.ExecuteReader();

            Courses.DataSource = dr2;
            Courses.DataTextField = "CourseInfo";
            Courses.DataValueField = "CourseInfo";
            Courses.DataBind();
            // Close the SqlDataReader
            dr2.Close();
        }


        protected void DropDownDataBindSemesters()
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True");
            conn.Open();

            SqlCommand cm1;
            string query1 = "SELECT CONCAT(Semester.season, '-', Semester.year) AS CourseInfo from Semester;";
            cm1 = new SqlCommand(query1, conn);
            SqlDataReader dr1 = cm1.ExecuteReader();

            Semesters.DataSource = dr1;
            Semesters.DataTextField = "CourseInfo"; // Specify the display field name from your data source
            Semesters.DataValueField = "CourseInfo"; // Specify the value field name from your data source
            Semesters.DataBind();
            // Close the SqlDataReader
            dr1.Close();
        }

        protected void Semesters_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownDataBindCourses();
            UpdateArrays();
        }

        protected void Courses_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateArrays();

        }

        protected void UpdateArrays()
        {
            // Clear the arrays to remove existing data
            studentids.Clear();
            status.Clear();


            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();

                string semester = Semesters.SelectedValue;
                int i = semester.IndexOf('-');

                string course = Courses.SelectedValue;
                string season = semester.Substring(0, i);
                string year = semester.Substring(i + 1, semester.Length - (i + 1));

                int cid = 0;
                int semid = 0;

                string query = "SELECT Course.course_id FROM OfferedCourses JOIN Course ON Course.course_id = OfferedCourses.course_id WHERE course_name = @course ";
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@course", course);

                    SqlDataReader dr = cm.ExecuteReader();
                    if (dr.Read())
                    {
                        cid = dr.GetInt32(0);

                        dr.Close();
                    }
                }

                string semQuery = "SELECT semester_id from Semester where season=@season and year = @year";
                using (SqlCommand cm1 = new SqlCommand(semQuery, conn))
                {
                    cm1.Parameters.AddWithValue("@season", season);
                    cm1.Parameters.AddWithValue("@year", year);

                    SqlDataReader dr = cm1.ExecuteReader();

                    if (dr.Read())
                    {
                        semid = dr.GetInt32(0);

                        dr.Close();
                    }


                }

                string studentQuery = "SELECT user_id,registered from AppliedforCourse where semester_id=@semid and course_id=@cid";
                using (SqlCommand cm1 = new SqlCommand(studentQuery, conn))
                {
                    cm1.Parameters.AddWithValue("@semid", semid);
                    cm1.Parameters.AddWithValue("@cid", cid);

                    SqlDataReader students = cm1.ExecuteReader();

                    while (students.Read())
                    {
                        string studentId = students.GetString(0);
                        string stat = students.GetString(1);

                        // Create labels for student ID and grade
                        Label lblStudentId = new Label();
                        lblStudentId.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + studentId + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; // Add 4 spaces between labels

                        Label lblStatus = new Label();
                        lblStatus.Text = stat;

                        // Add the labels to the lists
                        studentids.Add(lblStudentId);
                        status.Add(lblStatus);
                    }
                }
            }

            UpdateTable();
        }

        protected void UpdateTable()
        {
            // Remove existing table from the placeholder control
            TablePlaceholder.Controls.Clear();

            // Create a new table
            Table table = new Table();

            // Add rows and cells using the updated array data
            for (int rowIndex = 0; rowIndex < studentids.Count; rowIndex++)
            {
                TableRow row = new TableRow();

                // Add label to the first column of the row
                TableCell labelCell = new TableCell();
                labelCell.Controls.Add(studentids[rowIndex]);
                row.Cells.Add(labelCell);

                // Add name to the second column of the row
                TableCell nameCell = new TableCell();
                nameCell.Controls.Add(status[rowIndex]);
                row.Cells.Add(nameCell);

                // Add the row to the table
                table.Rows.Add(row);
            }

            TablePlaceholder.Controls.Add(table);
        }



        protected void Return_Click(object sender, EventArgs e)
        {
            Response.Redirect("Academic.aspx");
        }

        protected void Register_Click(object sender, EventArgs e)
        {
            //Check if prereq cleared

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();

                string semester = Semesters.SelectedValue;
                int i = semester.IndexOf('-');

                string course = Courses.SelectedValue;
                string season = semester.Substring(0, i);
                string year = semester.Substring(i + 1, semester.Length - (i + 1));

                int cid = 0;
                int semid = 0;

                string query = "SELECT Course.course_id FROM OfferedCourses JOIN Course ON Course.course_id = OfferedCourses.course_id WHERE course_name = @course ";
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@course", course);

                    SqlDataReader dr = cm.ExecuteReader();
                    if (dr.Read())
                    {
                        cid = dr.GetInt32(0);

                        dr.Close();
                    }
                }

                string semQuery = "SELECT semester_id from Semester where season=@season and year = @year";
                using (SqlCommand cm1 = new SqlCommand(semQuery, conn))
                {
                    cm1.Parameters.AddWithValue("@season", season);
                    cm1.Parameters.AddWithValue("@year", year);

                    SqlDataReader dr = cm1.ExecuteReader();

                    if (dr.Read())
                    {
                        semid = dr.GetInt32(0);

                        dr.Close();
                    }


                }

                List<string> sids = new List<string>();
                bool prereqclear = false; bool maxcourses = false;

                string studentQuery = "SELECT user_id from AppliedforCourse where semester_id=@semid and course_id=@cid";
                using (SqlCommand cm1 = new SqlCommand(studentQuery, conn))
                {
                    cm1.Parameters.AddWithValue("@semid", semid);
                    cm1.Parameters.AddWithValue("@cid", cid);

                    SqlDataReader students = cm1.ExecuteReader();

                    while (students.Read())
                    {
                        sids.Add(students.GetString(0));
                    }

                    students.Close();

                }


                for (int it = 0; it < sids.Count; it++)
                {
                    string preQuery = "SELECT prereq_id from Course where course_id = @cid";
                    int prereqid = -1;

                    using (SqlCommand cm1 = new SqlCommand(preQuery, conn))
                    {

                        cm1.Parameters.AddWithValue("@cid", cid);

                        SqlDataReader dr = cm1.ExecuteReader();

                        dr.Read();
                        prereqid = dr.GetInt32(0);
                        dr.Close();

                        if (prereqid == 0)
                        {
                            prereqclear = true;
                            continue;
                        }
                        else
                        {
                            string prerequery = "Select grade from Student_Semester_Section_Course where semester_id =@semid and course_id =@cid and user_id = @userid";
                            using (SqlCommand cm2 = new SqlCommand(prerequery, conn))
                            {

                                cm2.Parameters.AddWithValue("@cid", prereqid);
                                cm2.Parameters.AddWithValue("@semid", semid);
                                cm2.Parameters.AddWithValue("@userid", sids[it]);

                                SqlDataReader dr1 = cm2.ExecuteReader();

                                dr1.Read();

                                if (String.Equals(dr1.GetString(0), "I") || String.Equals(dr1.GetString(0), "F"))
                                {

                                }
                                else
                                {
                                    prereqclear = true;
                                }

                                dr1.Close();


                            }
                        }

                    }


                    string countQuery = "SELECT Count(*) from Student_Semester_Section_Course where user_id = @userid";
                    int count = 0;

                    using (SqlCommand cm1 = new SqlCommand(countQuery, conn))
                    {

                        cm1.Parameters.AddWithValue("@userid", sids[it]);

                        SqlDataReader dr = cm1.ExecuteReader();

                        dr.Read();
                        count = dr.GetInt32(0);
                        dr.Close();

                    }

                    if (count < 6)
                    {
                        maxcourses = true;
                    }

                    if (maxcourses && prereqclear)
                    {
                        string registerQuery = "UPDATE AppliedforCourse SET registered = 'R'  where user_id = @userid and semester_id=@semid and course_id = @cid";
               

                        using (SqlCommand cm1 = new SqlCommand(registerQuery, conn))
                        {

                            cm1.Parameters.AddWithValue("@userid", sids[it]);
                            cm1.Parameters.AddWithValue("@semid", semid);
                            cm1.Parameters.AddWithValue("@cid", cid);

                            cm1.ExecuteNonQuery();

                        }

                    }

                    maxcourses = false; prereqclear = false;

            }




         }

            UpdateArrays();
        }

        protected void SecAlloc_Click(object sender, EventArgs e)
        {
            Response.Redirect("Section.aspx");
        }
    }
}