﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Web.UI;
using Label = System.Web.UI.WebControls.Label;
using CheckBox = System.Web.UI.WebControls.CheckBox;

namespace FlexClutch
{
    public partial class OfferedCourses : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void OfferCourse_Click(object sender, EventArgs e)
        {
            string sem = Request.Form[Sem.UniqueID];
            string cc = Request.Form[CC.UniqueID];
            string cn = Request.Form[CN.UniqueID];
            int credithours = int.Parse(Request.Form[CH.UniqueID]);
            string prereq = Request.Form[PreReq.UniqueID];

            int i = sem.IndexOf('-');
            string season = sem.Substring(0, i);
            string year = sem.Substring(i + 1, sem.Length - (i + 1));

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();

                int semid = 0; int cid = 0; int prereqid = 0;

                string query = "select count(*) from Semester";
                using (SqlCommand cm = new SqlCommand(query, conn))
                {

                    semid = Convert.ToInt32(cm.ExecuteScalar());
                    semid += 1;
                }

                string query1 = "select count(*) from Course";
                using (SqlCommand cm = new SqlCommand(query1, conn))
                {
                    cid = Convert.ToInt32(cm.ExecuteScalar());
                    cid += 1;

                }

                if (!String.Equals(prereq, "0"))
                {
                    string pre = "select course_id from Course where course_code = @prereq";
                    using (SqlCommand cm = new SqlCommand(pre, conn))
                    {
                        cm.Parameters.AddWithValue("@prereq", prereq);

                        object result = cm.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            prereqid = Convert.ToInt32(result);
                            // Continue with further processing using prereqid as needed
                        }
                        else
                        {
                            MessageBox.Show("Prerequisite does not exist");
                            return;
                        }

                    }
                }
                else
                {
                    prereqid = 0;
                }

                //check if semester or course already exits
                bool semexists = false;
                bool courseexists = false;
              

                string ifquerys = "select * from Course where course_name=@coursename";
                using (SqlCommand cm1 = new SqlCommand(ifquerys, conn))
                {
                    cm1.Parameters.AddWithValue("@coursename", cn);
                    SqlDataReader dr = cm1.ExecuteReader();
                   
                    if (dr.HasRows)
                    {
                        courseexists = true;
                    }
                    dr.Close();
                }

                string ifqueryc = "select * from Semester where season=@season and year = @year";
                using (SqlCommand cm = new SqlCommand(ifqueryc, conn))
                {
                    cm.Parameters.AddWithValue("@season", season);
                    cm.Parameters.AddWithValue("@year", year);
                    SqlDataReader dr = cm.ExecuteReader();
                 
                    if (dr.HasRows)
                    {
                        semexists = true;
                    }
                    dr.Close();
                }

                if (!semexists)
                {
                    string addsem = "Insert into Semester Values(@semid,@season,@year)";
                    using (SqlCommand cm = new SqlCommand(addsem, conn))
                    {
                        cm.Parameters.AddWithValue("@semid", semid);
                        cm.Parameters.AddWithValue("@season", season);
                        cm.Parameters.AddWithValue("@year", year);
                   
                       
                        cm.ExecuteNonQuery();
                    }

                }

                if (!courseexists)
                {
                    string addc = "Insert into Course Values(@cid,@coursename,@coursecode,@credit,@coord,@prereq)";
                    using (SqlCommand cm = new SqlCommand(addc, conn))
                    {
                        cm.Parameters.AddWithValue("@cid", cid);
                        cm.Parameters.AddWithValue("@coursename", cn);
                        cm.Parameters.AddWithValue("@coursecode", cc);
                        cm.Parameters.AddWithValue("@credit", credithours);
                        cm.Parameters.AddWithValue("@coord", "notset");
                        cm.Parameters.AddWithValue("@prereq", prereqid);
                     
                     
                        cm.ExecuteNonQuery();
                    }

                }


                string checkoffc = "Select count(*) from AppliedforCourse where course_id = @cid and semester_id = @semid and registered ='R'";
                using (SqlCommand cm = new SqlCommand(checkoffc, conn))
                {
                    cm.Parameters.AddWithValue("@cid", cid);
                    cm.Parameters.AddWithValue("@semid", semid);
                    SqlDataReader dr = cm.ExecuteReader();
                    dr.Read();
                    if (dr.GetInt32(0) < 10)
                    {
                        MessageBox.Show("Less than 10 students applied for this course so it cannot be offered");
                        return;                        
                    }

                    dr.Close();
                    
                }



                string addoffco = "Insert into OfferedCourses Values(@cid,@semid)";
                using (SqlCommand cm = new SqlCommand(addoffco, conn))
                {
                    cm.Parameters.AddWithValue("@cid", cid);
                    cm.Parameters.AddWithValue("@semid", semid);
                  
                    cm.ExecuteNonQuery();
                }


            }
        }

        protected void GenRep_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True"))
            {
                conn.Open();
                string message = "Offered Courses Report: \n";
                string ifqueryc = "SELECT CONCAT(Semester.season, '-', Semester.year) AS semester, STRING_AGG(Course.course_name, ',') AS course_names FROM OfferedCourses JOIN Course ON OfferedCourses.course_id = Course.course_id JOIN Semester ON Semester.semester_id = OfferedCourses.semester_id GROUP BY OfferedCourses.semester_id, Semester.season, Semester.year;";
                using (SqlCommand cm = new SqlCommand(ifqueryc, conn))
                {
                    SqlDataReader dr = cm.ExecuteReader();

                    while (dr.Read())
                    {
                        message = message + "Semester: " + dr.GetString(0) + "   Offered Courses: " + dr.GetString(1) + "\n";
                    }
                    MessageBox.Show(message);
                }

            }
        }

        protected void Return_Click(object sender, EventArgs e)
        {
            Response.Redirect("Academic.aspx");
        }
    }
}