﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;
using System.Windows.Forms;




namespace FlexClutch
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True");
            conn.Open();
            SqlCommand cm;
            string un = txtun.Text;
            string pass = txtpass.Text;
            string query = "select * from users where user_id = '" + un + "' and password = '" + pass + "'";
            cm = new SqlCommand(query, conn);
            SqlDataReader dr = cm.ExecuteReader();
            dr.Read();


            if (dr.HasRows && dr.GetValue(4).ToString() == "S")
            {
                Session["dr"]= dr;

                // Redirect to WebForm2
                Response.Redirect("Student.aspx");

            }
            else if (dr.HasRows && dr.GetValue(4).ToString() == "F")
            {
                Session["dr"] = dr;

                // Redirect to WebForm2
                Response.Redirect("Faculty.aspx");
            }
            else if (dr.HasRows && dr.GetValue(4).ToString() == "A")
            {
                Session["dr"] = dr;

                // Redirect to WebForm2
                Response.Redirect("Academic.aspx");
            }

            else
            {
                MessageBox.Show("LOGIN FAILED");
            }

        }
    }
}