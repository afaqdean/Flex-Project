﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Web.SessionState;

namespace FlexClutch
{

    public partial class WebForm2 : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
          
            SqlDataReader _reader = (SqlDataReader)Session["dr"];

            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FGU1HQQ;Initial Catalog=Flex;Integrated Security=True");
            conn.Open();


            //No of courses taught by instructor
            SqlCommand cm;
            string query = "select count(*) from Faculty_Semester_Section_Course where user_id = '" + _reader.GetString(0) + "'"; //courses taught by faculty
            cm = new SqlCommand(query, conn);
            SqlDataReader dr = cm.ExecuteReader();
            dr.Read();
            int coursestaught = dr.GetInt32(0);
            dr.Close();

            //Which courses to display
            SqlCommand cm1;
            string query1 = "select course_code,course_name,section_name,user_id from Faculty_Semester_Section_Course join Course on Faculty_Semester_Section_Course.course_id = Course.course_id  where user_id = '" + _reader.GetString(0) + "'"; //courses taught by faculty
            cm1 = new SqlCommand(query1, conn);
            SqlDataReader dr1 = cm1.ExecuteReader();

            if (coursestaught >= 3)
            {

                dr1.Read();
                Course1.Text = dr1.GetValue(0).ToString();
                Title1.Text = dr1.GetValue(1).ToString();
                Section1.Text = dr1.GetValue(2).ToString();
                Teacher1.Text = dr1.GetValue(3).ToString();


                dr1.Read();
                Course2.Text = dr1.GetValue(0).ToString();
                Title2.Text = dr1.GetValue(1).ToString();
                Section2.Text = dr1.GetValue(2).ToString();
                Teacher2.Text = dr1.GetValue(3).ToString();

                dr1.Read();
                Course3.Text = dr1.GetValue(0).ToString();
                Title3.Text = dr1.GetValue(1).ToString();
                Section3.Text = dr1.GetValue(2).ToString();
                Teacher3.Text = dr1.GetValue(3).ToString();
            }
            else if (coursestaught == 2)
            {
                dr1.Read();
                Course1.Text = dr1.GetValue(0).ToString();
                Title1.Text = dr1.GetValue(1).ToString();
                Section1.Text = dr1.GetValue(2).ToString();
                Teacher1.Text = dr1.GetValue(3).ToString();
                dr1.Read();
                Course2.Text = dr1.GetValue(0).ToString();
                Title2.Text = dr1.GetValue(1).ToString();
                Section2.Text = dr1.GetValue(2).ToString();
                Teacher2.Text = dr1.GetValue(3).ToString();
               // dr1.Read();
                Course3.Visible = false;
                Title3.Visible = false;
                Section3.Visible = false;
                Teacher3.Visible = false;
            }
            else if (coursestaught == 1)
            {
                dr1.Read();
                Course1.Text = dr1.GetValue(0).ToString();
                Title1.Text = dr1.GetValue(1).ToString();
                Section1.Text = dr1.GetValue(2).ToString();
                Teacher1.Text = dr1.GetValue(3).ToString();
                // dr1.Read();
                Course2.Visible = false;
                Title2.Visible = false;
                Section2.Visible = false;
                Teacher2.Visible = false;
                // dr1.Read();
                Course3.Visible = false;
                Title3.Visible = false;
                Section3.Visible = false;
                Teacher3.Visible = false;
            }


           // Session.Remove("dr");

        }

        protected void marks_Click(object sender, EventArgs e)
        {
            SqlDataReader _reader = (SqlDataReader)Session["dr"];
            Session["cr"] = _reader; 
            Response.Redirect("Distributions.aspx");
        }

        protected void eval_Click(object sender, EventArgs e)
        {
            SqlDataReader _reader = (SqlDataReader)Session["dr"];
            Session["sr"] = _reader;
            Response.Redirect("Evaluations.aspx");
        }

        protected void attend_Click(object sender, EventArgs e)
        {
            SqlDataReader _reader = (SqlDataReader)Session["dr"];
            Session["ar"] = _reader;
            Response.Redirect("Attendance.aspx");

        }

        protected void grades_Click(object sender, EventArgs e)
        {
            SqlDataReader _reader = (SqlDataReader)Session["dr"];
            Session["gr"] = _reader;
            Response.Redirect("Grades.aspx");

        }

        protected void feedback_Click(object sender, EventArgs e)
        {
            SqlDataReader _reader = (SqlDataReader)Session["dr"];
            Session["fr"] = _reader;
            Response.Redirect("FeedbackReport.aspx");
        }

        protected void LogOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }
    }


}